# 04 · Implementation guide

The whole front end is one file, `nammaoe2bot/web/page.html` (inline CSS and
JS, no build step), served by `nammaoe2bot/web/server.py`. The content security
policy allows inline script and style, images over `https:` and `data:`, and
fonts from Google only. External scripts are not allowed, so no frameworks or
icon fonts.

## How the page is put together

- **Routing.** `showPage(page)` switches `.page` divs and updates the URL.
  `routePath` and `applyRouteFromLocation` map paths to pages; `/add-bot` is
  deliberately not community-scoped. `showPage` also highlights the top-bar
  link and asks before leaving the dashboard with unsaved settings.
- **Auth.** `checkAuth()` reads `/api/me` into `currentUser` (`user_id`,
  `username`, `avatar`, `csrf`, `oauth_enabled`, `invite_url`) and keeps
  `botInviteUrl` even when sign-in is off. `authFetch()` attaches the CSRF
  header to every POST. `rememberLoginReturn(page)` plus `bootApp()` bring an
  admin back to the wizard or dashboard after the OAuth round trip (the
  callback always lands on `/`).
- **Dashboard state** is a handful of `dash*` globals (`dashGuildId`,
  `dashChannels`, `dashQueues`, `dashConfigData`, `dashOverviewData`, …).
  Each view is a `render*` or `open*` function that writes `#dash-content`.
- **Navigation handlers take list indexes**, not names: `selectGuildAt(i)`,
  `selectChannelAt(i)`, `selectQueueAt(i)`. Names are user text and used to be
  spliced into inline `onclick` strings, which broke on a quote. Keep it that
  way.
- **Escaping.** `esc()` is for text nodes. **Use `attr()` inside
  double-quoted attributes**: `esc()` leaves `"` alone.

Phone and tablet behaviour is described in `07-mobile.md`. All phone CSS
is one block at the end of the `<style>` element.

## Function map

| Area | Functions |
| --- | --- |
| Icons | `UI_ICONS`, `icon(name)`, `avatarHtml(user, cls)` |
| Wizard | `renderAddBotWizard`, `addBotStepHtml(step)`, `goAddBotStep`, `openAddBotAt(step)`, `addBotCheck`, `copyCommand`, `launchConfetti` |
| Dashboard shell | `loadDashboard`, `selectGuild`, `renderGuildNav`, `renderGuildMenu`, `renderBreadcrumb`, `backToOverview`, `dashEmptyState` |
| Overview | `renderCommunityOverview`, `progressRing`, `setupStepAction`, `FEATURE_ICONS` |
| Settings | `renderConfigView`, `renderConfigSection`, `renderVariable`, `renderSettingControl`, `renderBoolControl`, `renderInputControl`, `renderTableControl`, `settingHelp`, `settingTip`, `filterSettings`, `switchTab`, `resetSetting`, `markDirty`, `updateSavebar`, `confirmDiscard`, `collectFormData`, `saveSettings`, `saveChannelConfig`, `saveQueueConfig` |
| Tool page kit | `apPage`, `apSection`, `apRow`, `apTabset`/`apTab`, `apDrop`/`apFilePicked`, `apCounts`, `apResult`, `apWho`, `apNoChannels`, `statusTone`, `sentenceLabel`, `RESULT_LABELS` |
| Tool pages | `openQuizSettings`/`saveQuizSettings`, `openCommunityPolicy`/`saveCommunityPolicy`, `openCommunityDiagnostics`/`renderCommunityDiagnostics`/`runDiagnosticAction`, `openRatingSeed`/`renderRatingSeedForm`/`renderRatingSeedPreview`/`renderTeamRatingSeedPreview`/`apply*`, `openIdentityImport`/`renderIdentityPreview`/`applyIdentityImport`, `openHistoricalMigration`/`renderHistoricalMigrationForm`/`renderHistoricalMigrationPreview`/`applyHistoricalMigration` |

**Tests pin some of these names and strings** (`tests/test_web_repoint.py`,
`test_tenant_aware_admin_routes_are_registered_and_used_by_the_spa` and
`test_the_add_bot_wizard_route_serves_the_spa`): the function names above,
`adminCommunityApi(…)`, the three API path fragments, `publicCommunityId =
String(id)`, `currentUser.invite_url`, and the sentence "It never overwrites an
existing rating". Renaming any of them fails CI on purpose.

## API contracts the design relies on

All admin routes live under `/api/admin/communities/{id}/…` and need a session
and, for POST, the CSRF header.

| UI | Endpoint | Fields used |
| --- | --- | --- |
| Top bar, wizard | `GET /api/me` | `logged_in`, `oauth_enabled`, `username`, `avatar`, `user_id`, `csrf`, **`invite_url`** (new; `null` when `DC_CLIENT_ID` is unset) |
| Wizard final step, server rail | `GET /api/admin/communities` | `communities[].id/name/icon/channels` |
| Overview | `…/overview` | `onboarding.steps[]` (`key`, `title`, `status`, `required`, `detail`, `action`), `capabilities[]` (`key`, `title`, `status`, `scope`, `configurable`, `summary`, `metrics`, `note`), `diagnostics` |
| Settings | `…/channels/{c}/config`, `…/queues/{q}/config` | `sections[]`, `variables{name: {type, display, description, section, notnull, default, value, options, min, max, unit, columns}}`, `is_admin` |
| Save settings | POST same paths | body has **only edited keys**; `null` means "not set"; bools as `"on"`/`"off"`; tables as row lists |
| Quiz | `…/quiz` | `channels[]` (`id`, `name`, `enabled`, `quiz_hour`, `open_window`), `active_channel_id` |
| Access | `…/policy` | `policy.dashboard_visibility`, `allowed_dashboard_visibilities`, `replay_analysis_requested`, `replay_reason`; `deployment.mode`, `deployment.replay_available` |
| Diagnostics | `…/diagnostics` | `status`, `summary.critical/warnings`, `checks[]` (`title`, `status`, `detail`, `metrics`, `action.target/label`) |
| Imports | `…/ratings/seed/{preview,apply}`, `…/ratings/seed/aoe-team/{preview,apply}`, `…/identities/import/{preview,apply}`, `…/migration/pubobot/{preview,apply}` | unchanged; previews return `summary`, `rows[]` (`status`, `message`, …), `can_apply`, `digest`, `target`, `blockers` |

**Setting text comes from the backend.** The `description` of each
`Variables.*Var` in `pickup/channel.py` and `pickup/queue.py` is what the UI
shows. Lines shaped like `"  option - meaning"` are parsed into option help
(see `settingHelp`). Fix wording there, not in the page.

## Recipes

**Add a setting.** Declare it in `channel.py` or `queue.py` with `display`,
`section` and a plain-language `description`. It appears automatically. A new
`section` name needs an entry in `SECTION_INFO` (icon and blurb) or it gets the
generic icon.

**Add an admin tool page.**
1. Write `openX()` that builds HTML with `apPage(title, lede, body, aside)`,
   using `apSection`, `apRow` and `.ap-choice` markup, and ends with an `.ap-foot`.
2. Use labelled inputs (`.cfg-input`, `.cfg-select`, `.cfg-switch`), never
   placeholder-only fields.
3. For anything that writes data: preview first, render with `apCounts` +
   `.ap-table` + `apResult`, and give the apply button `id="ap-apply"` and a
   label naming the outcome.
4. Link it from the overview (`setupStepAction`, a feature card, or the hero
   actions) and handle its `target` in `runDiagnosticAction` if a diagnostic
   can point at it.

**Add or change a wizard step.** Steps are `ADDBOT_STEPS` (labels) plus the
`step === n` branches of `addBotStepHtml`. Each step returns text and a
`.dc-mock` preview. If a step happens outside this site, say so in an
`addBotNote('info', …)` naming the reply to wait for. The owner does not want
detection or a confirmation checkbox.

**Other platforms.** The owner is adapting the bot to more platforms. Keep
platform specifics (invite URL, command syntax, permission wording,
Discord-styled previews) in the step content, so a platform switch can supply
its own `ADDBOT_STEPS` and step bodies. The backend should then return
per-platform invite data instead of the single `invite_url`. See backend notes.

## Verifying changes

```bash
ruff check .
pytest tests/
python3 -c "s=open('nammaoe2bot/web/page.html').read(); open('/tmp/p.js','w').write(s[s.index('<script>')+8:s.rindex('</script>')])" && node --check /tmp/p.js
```

Then rebuild the prototype and screens (`README.md`) and look at them at
1440px and 390px. Several layout bugs in this work, such as the save bar
pinned mid-page and nested text collapsing to 15px, only showed up in a real
browser.
