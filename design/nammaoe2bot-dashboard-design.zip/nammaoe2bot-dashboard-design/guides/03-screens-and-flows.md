# 03 · Screens and flows

Screen numbers match `screens/desktop/` (D) and `screens/mobile/` (M). The
prototype menu names are in brackets.

## Global frame

**Top bar.** Brand mark + "NammaAoE2Bot" + version chip (see backend notes:
the version is hard-coded and wrong), then Leaderboard, Match Stats, Civ Stats,
Strategies and Settings with icons. The current page is highlighted. On the
right: avatar and name when signed in, the **Add to Discord** button (always
visible, it is the product's entry point), and Login or Log out. Below 900px
the link labels hide and only icons remain.

**Settings frame** (any dashboard page). On the left, a server rail (server
icons plus a "+" that opens the wizard at the invite step). Next to it, the
channel sidebar: server name, Overview, "Pickup channels" with each channel's
queues nested under the selected channel, then "Create a queue" and "Enable a
channel", which open the matching wizard steps. On phones the sidebar is a
drawer opened from the sticky context bar (☰ Server › #channel), and the main
pages move to a bottom tab bar. See `07-mobile.md` for every phone
adaptation.

## 1. Setup wizard: `/add-bot`

Reached from the top-bar button, the "+" in the server rail, empty states and
"Show me how" buttons. Progress is kept in `sessionStorage`, so it survives
the Discord tab and the sign-in round trip (sign-in returns to the wizard, not
the home page).

Layout: a gradient hero (headline "Bring ranked AoE2 pickups to your Discord
server", feature chips, animated mark), a five-node stepper (clickable,
completed nodes show a check), then a step card with instructions on the left
and a Discord-style preview on the right.

| # | Step | Content | Leaves when |
| --- | --- | --- | --- |
| D01 | Sign in [wizard signed out] | Why sign-in is needed; only username and avatar are shared. "Continue with Discord", or "Skip for now". If web sign-in isn't configured, a note says to use `/channel set` and `/queue set` in Discord | Signed in (skipped automatically), or skipped |
| D02, M01 | Invite [wizard invite] | What the bot can do, each line naming the Discord permissions behind it. A big **Add to Discord** button opens Discord's invite in a new tab. Note: *the page can't see Discord's tab finish; come back once Discord says the bot was added*; never asks for Administrator; removable under Integrations. No invite configured → a warning naming `DC_CLIENT_ID` | "Next: enable a channel" appears after the invite opens; "It's already in my server" skips |
| D03, M02 | Enable channel [wizard enable channel] | Copyable `/channel enable`; needs Administrator. Note: *you do this in Discord, so this page can't check it; continue once the bot replies "The bot has been enabled."*, plus the slash-command delay tip | "Done, next step" |
| D04 | Create queue [wizard create queue] | Copyable `/queue create_pickup name:4v4 size:8`; how players join (`/add`, `++`). Note: *happens in Discord too; continue once the bot replies with your queue; new queues start unranked* | "Done, check my server" |
| D05 | Launch [wizard check] | Asks the server for communities the admin manages. Found: confetti, server cards, "Open settings". Not found: what to check, then "Check again". Signed out: "Sign in to finish" | Opens the dashboard for that server |

Per the owner, steps 3 and 4 are deliberately **not** detected or confirmed
with a checkbox. The note on each step is the whole mechanism.

## 2. Dashboard entry states

- **D06, M03 · Signed out** [dashboard signed out]: a centred card, "Sign in
  to manage your server", "Continue with Discord", and "New here? Add the bot".
  If OAuth is off: "Web settings are turned off", pointing at Discord commands.
- **D07 · No servers** [dashboard no servers]: "No servers yet", what it means,
  "Add the bot to a server" (wizard at invite) and "Check again".

## 3. Overview: D08, M04 [overview]

- Hero panel: server icon or letter, name, one-line state ("Finish the
  highlighted step…" or "Everything required is set up…"), actions (Run
  diagnostics, Access & compute, Add a channel), and a progress ring counting
  required setup steps.
- **Setup checklist**: numbered rows with a check when done. The next required
  step is outlined in accent. Optional steps say "Optional". Each row has its
  action (Seed ratings, Map profiles, Import history) or, for the two
  Discord-side steps, "Show me how" (opens the wizard).
- **Pickup channels**: cards that open channel settings, plus "Enable a
  channel".
- **Features**: a card per capability with an icon, status, scope and metrics.
  The quiz card has "Configure quiz".
- **Health**: Discord and runtime status with dots, then data counts, and
  "Run full diagnostics".

## 4. Channel and queue settings: D09–D14, M05 [channel settings] [queue settings]

- Header: a tinted icon (# for a channel, list icon in gold for a queue), name,
  scope sentence, and the **Search settings** box.
- Left column: categories with icon, count and a gold dot when a category has
  unsaved edits. Below 900px this becomes a horizontal strip.
- Right column: the active category's title and blurb, then the rows (see
  `02-design-system.md`, "Settings row").
- **D10 · Unsaved**: edited rows get a gold rule and an "Unsaved" tag; the save
  bar slides up with the count, Discard and Save changes.
- **D11 · Info tooltip**: default, format, Discord command, option meanings.
- **D12 · Search**: matches names, keys, descriptions and option text across
  all categories, groups results by category, and has an empty state.
- **D13 · Option help**: the line under a select explains the chosen option and
  updates live.
- **D14 · Tables**: inline add and remove, plus an empty state.
- Reset (↺, shown on row hover, always shown on touch) restores the default
  and marks the row unsaved.
- Save sends only edited settings, re-reads from the server so the form shows
  what the bot stored, and keeps the current category. Renaming a queue
  refreshes the sidebar.

## 5. Admin tool pages

All share: a breadcrumb (server › page), title, one-sentence lede, an optional
status or action on the right, a narrow single column, and a sticky footer with
the primary action.

### Daily quiz: D15, M06 [daily quiz]
Status at top right ("Posting in #pickups at 18:00 UTC" or "Not posting").
Rows: Channel (moving the quiz turns it off in the old channel), "Post a
question every day" switch (open questions still pay out), Post time in UTC
with a live "That is 23:30 in Asia/Kolkata" line, and Voting window in hours
(0.25–24). The lede states the rewards: 50 gold for a correct answer, 10 for a
vote, for players under 500 gold.

### Access & compute: D16 [access compute]
"Who can view the stats pages" as three radio cards (Anyone with the link /
Server members / Admins only), each stating the consequence. A copyable
leaderboard link. A replay analysis switch with the reason in plain words, and
locked with an "Unavailable here" note when the deployment can't run it.

### Diagnostics: D17, M08 [diagnostics]
A headline with tone ("1 problem needs attention", "Everything checks out"),
"N of M checks passing", and the time checked. Checks are ruled rows sorted
problems first: a status mark, title, detail, monospace metrics, and a fix
button when the API offers one. Footer: counts only, no member data. "Run
again" at top right.

### Seed player ratings: D18–D22, M07 [seed ratings]
1 **Destination**: channel. 2 **Source**: tabs, *Upload a file* (drop zone,
format help, CSV sample), *One player* (labelled fields; deviation and nickname
optional; how to copy a Discord user ID), *AoE2 team ratings* (what it does;
once per channel; a link to profile linking). 3 **Review and apply**: the
three guarantees, then the preview: counts, a table (line, player name over ID,
rating, deviation, result with dot, word and reason), and the footer (source →
channel, Discard, **Apply N ratings**). The team-ratings review adds blockers,
the selection policy and per-profile ratings.

### Link AoE2 profiles: D23 [link profiles]
1 **Source**: *Upload a file* (CSV or ZIP, sample) or *One player* (Discord user
ID, AoE2 profile ID, "the number at the end of the aoe2companion.com profile
link"). 2 **Review and link**: four rules (members only, never moves a profile
owned by someone else, names in the file are labels only), then the preview
and **Link N profiles**. The lede points players at `/profile_link`.

### Import match history: D24 [import history]
1 **Destination**: channel and the export's time zone (prefilled from the
browser). 2 **Export file**: ZIP drop zone, "Run preflight" ("reads the file
and checks the channel; saves nothing"). 3 **Review and import**: a callout
listing the four conditions the import requires. The preview shows counts
with separators, then either "Can't import yet" with blockers (Import
disabled) or "Preflight passed", and the footer **Import N matches**.

## Copy rules used throughout

- Sentence case everywhere except proper nouns. Curly quotes and apostrophes
  in UI copy.
- Buttons say what happens: "Check file", "Run preflight", "Apply 3 ratings",
  never "Submit" or "OK".
- Empty and error states say what happened and what to do next.
- Numbers use the reader's locale separators.
