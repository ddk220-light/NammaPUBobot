# 05 · Backend notes

Open work for the backend agent, raised while designing the dashboard. Each
item says what is true now (with file references), what is in doubt, and what
the product owner asked for. Items B1–B4 were requested explicitly by the
owner; B5 onwards came up during the work.

Paths are relative to the repository root. Line numbers drift, so search for
the named symbol.

---

## B1 · Verify and fix the bot's invite permissions *(owner request)*

**Now.** `nammaoe2bot/web/server.py` defines `BOT_INVITE_PERMISSIONS` and
`_bot_invite_url()`. `/api/me` returns `invite_url` built from `DC_CLIENT_ID`,
scopes `bot applications.commands`, and permissions `268815424`:

| Bit | Permission | Why the design included it |
| --- | --- | --- |
| 1<<10 | View Channels | Read the queue channel |
| 1<<11 | Send Messages | Queue cards, replies |
| 1<<14 | Embed Links | Every card is an embed |
| 1<<15 | Attach Files | Images and charts the bot posts |
| 1<<16 | Read Message History | Re-find its own cards after a restart |
| 1<<6 | Add Reactions | Check-in reactions (`pickup/match/checkin.py`, `add_reaction`) |
| 1<<18 | Use External Emojis | Rank and civ emoji |
| 1<<28 | Manage Roles | Rank roles (`pickup/channel.py`, `_update_rating_roles`) |

This list was **inferred by reading calls in the code, not confirmed against
a live server**. Please audit:

- Anything that needs more than the above: editing nicknames (the
  `rating_nicks` setting says "Add [rating] prefix to guild members
  nicknames", which would need **Manage Nicknames**), threads, voice moves,
  pins, deleting other users' messages, `@everyone` or role mentions (the old
  `Queue.promote` checked `mention_everyone`).
- Anything listed above that is not needed (for example Attach Files, if the
  rendered charts stay paused).
- **Privileged gateway intents.** `runtime/client.py` enables `presences`,
  `members` and `message_content`. These are not invite permissions: they are
  switched on in the Discord Developer Portal, and a bot in **100 or more
  servers needs Discord's verification approval for them**. Auto-remove on
  AFK or offline, member lookups for profile linking, and the `++`/`--`
  shortcuts depend on them. Since the bot is going public, plan for
  verification or for graceful degradation without them.
- `/channel enable` requires the **Administrator** permission
  (`discord/slash.py`, `enable_channel`), while the web dashboard accepts
  **Manage Server** (`web/server.py`, `_member_is_admin`). The wizard tells
  admins they need Administrator for that step. Decide whether the two should
  match.

**If the set changes**, update `BOT_INVITE_PERMISSIONS`, the "What the bot will
be able to do" list in `page.html` (`addBotStepHtml`, `step === 1`) and
`test_the_add_bot_link_asks_only_for_the_permissions_the_bot_uses` in
`tests/test_web_repoint.py` (which asserts Administrator is never requested).

**Other platforms.** The owner is adapting the bot to other platforms.
`invite_url` is Discord-only today. Suggested shape when a second platform
lands: `/api/me` (or a public `/api/platforms`) returns
`platforms: [{key, name, invite_url, required_permissions: [...]}]`, and the
wizard renders a platform picker before step 2.

---

## B2 · Decide what happens to the `prefix` setting *(owner request)*

**Now.** `pickup/channel.py` still declares `StrVar("prefix")`, default `"!"`.
Nothing reads it (searched for `cfg.prefix`, `cfg['prefix']` and
`.get('prefix')`); text commands were removed and only `++`/`--` remain, which
don't use a prefix. The description now says: "Legacy setting kept for older
configs. Commands are slash commands now, so this has no effect."

**Look into:**
- Removing the variable. Settings live in the `cfg_data` JSON blob of
  `channel_settings` (`runtime/cfg_factory.py`, `FactoryTable`), so removal
  leaves a stale key but needs no column drop. Check whether `FACTORY_VERSION`
  or a migration in `runtime/migrations.py` is expected for a removed key, and
  that `/channel show` and `/channel set` autocomplete
  (`discord/autocomplete.py`) cope.
- The same audit found **three more settings with no reads anywhere**:
  - channel `promotion_delay` (see B3),
  - channel `description` and queue `description` ("Set an answer on '!help'
    command"). `!help` no longer exists.

  Decide remove, or re-wire (for example, show the description in `/add`
  replies or on the queue card).

---

## B3 · Review the setting descriptions *(owner request)*

The UI shows each setting's `description` verbatim, so these strings are now
user-facing help. I rewrote or added the ones below, checking each against the
code. **Please confirm each, and resolve the doubts.**

| Setting | Current text (short) | Evidence | Doubt or decision needed |
| --- | --- | --- | --- |
| channel/queue `promotion_role` | "Currently unused: the promote command was removed, so nothing pings this role." | `Queue.promote` (`pickup/queue.py`) has **no callers** since `/promote` went in the command consolidation | Remove `promotion_role`, `promotion_delay` and `promotion_msg`, or bring back a promote command. Until then the UI honestly says "unused" |
| channel `promotion_delay`, queue `promotion_msg` | "Currently unused: …" | Same | Same |
| channel `remove_afk` | "…when their Discord status turns Idle. Skipped while their timed auto-remove is running." | `discord/events.py`, `on_presence_update`: `qc.cfg.remove_afk and expire.get(qc, after) is None` | When `expire_time` is set, **every** `/add` starts a timer (`QueueChannel.update_expire`), so AFK removal **effectively never fires** in that channel. Intended? If not, fix the condition; if so, keep the text |
| channel `remove_offline` | "…when they go offline on Discord." | `events.py`, presence handler | Needs the presences intent (B1) |
| channel `expire_time` | "…this long after they last joined. Leave unset to keep them queued." | `pickup/expire.py`, `set()` replaces the timer per (channel, member) | "Last joined" assumes re-adding resets it. That matches `set()`, but please confirm |
| channel `admin_role`, `moderator_role` | "Members with this role can change the bot's settings…" | Honoured by Discord commands (`discord/context.py`, `check_perms`) | **Not** honoured by the web dashboard: `_member_is_admin` checks bot owner, guild owner and Manage Server only. Either make the web honour `admin_role` or change the text to "…in Discord" |
| channel `blacklist_role`, `whitelist_role` (+ queue) | "…can't join any queue in this channel" / "only players with this role can join" | `pickup/channel.py` around `check_allowed_to_add`, `pickup/queue.py` | Looks right |
| channel `ranks` (table) | Added: "Rank labels shown next to player names. A player gets the highest rank whose rating they have reached." | Column help in the same declaration | Confirm. The `role` column accepts a role **name, ID or `<@&id>` mention** (`RoleVar.validate`); the web gives no hint. Consider column-level help in the API |
| channel `lang` | unchanged: "Select bot translation language" | `runtime/locales.py`, `_LANGS = ("en",)` | Only one option exists. Hide the setting until there is a second language? |
| channel `prefix` | see B2 | | |
| queue `name` | "One word players use to join this queue, for example 4v4." | `PickupQueue.validate_name` rejects `:` and whitespace | `verify_message` also mentions `+-`, which the check doesn't enforce. Align them |
| queue `size` | "How many players fill the queue and start a match." | | Only starts automatically if `autostart` is on |
| queue `is_default` (now "Default queue") | "Players join this queue with a plain /add or ++, without naming it." | `discord/commands/queues.py`, `add` | Simplified. Real rule: one queue in the channel → always that one; otherwise default queues **that already have players**, or all default queues if none do |
| queue `ranked` (now "Ranked queue") | "Matches from this queue change player ratings and appear on the leaderboard." | `pickup/stats.py`, `register_match_unranked` | Confirm unranked matches never touch the leaderboard |
| queue `autostart` | "Start the match automatically as soon as the queue fills up." | `PickupQueue.add_member` | Looks right |

Copy on the new pages that makes factual claims, to confirm:
- **Daily quiz:** "A correct answer earns 50 gold and any vote earns 10, for
  players under 500 gold" (from `features/betting/gold.py`,
  `grant_quiz_reward`).
- **Access & compute:** "Settings pages always need a server manager", and
  replay analysis "runs on this installation's own hardware".
- **Link profiles:** "The profile ID is the number at the end of the player's
  aoe2companion.com profile link" (matches `/profile_link` in
  `features/identity/commands.py`).
- **Seed ratings, One player:** deviation optional → the channel default
  (`web/onboarding.py`, `parse_seed_payload`).

---

## B4 · Show the real version in the top bar *(owner request)*

**Now.** `page.html` hard-codes `<div id="tb-botinfo-version">v0.8 beta</div>`,
but `nammaoe2bot/__init__.py` says `__version__ = "2.0.0"`.

**Do:** return the version from the server, either a `version` field on
`/api/me` (both signed-in and signed-out branches) or a small public
`/api/meta`. Then have `renderAuth()` (or boot) fill `#tb-botinfo-version`,
falling back to hiding the chip. Optionally append the short commit SHA on
non-production deployments (Railway sets `RAILWAY_GIT_COMMIT_SHA`).

---

## B5 · Things the wizard depends on

- `DC_CLIENT_ID` must be set in every deployment (in `start.py`'s template).
  Without it `invite_url` is `null` and the wizard shows "no invite link
  configured".
- `GET /api/admin/communities` is how the wizard's last step decides "you're
  all set". A community appears only after `/channel enable` enrolls a channel
  (`community.enroll_channel`). If enrolment ever becomes asynchronous, the
  "Check again" copy still holds.
- By owner decision there is **no** endpoint to detect steps 3 and 4 (channel
  enabled, queue created), and no checkbox. Don't add one unasked.

## B6 · Small API improvements the UI would use

- Settings payload: per-column help for table settings (for example the `role`
  column), and a `readable_default`, so the UI doesn't convert raw defaults
  (seconds, 1/0) itself.
- Queue list (`…/queues`): include `ranked` and `size`, so the sidebar can show
  "4v4 · 8 · ranked" without opening each queue.
- Overview `onboarding.steps[].detail` strings use "channel(s)" and
  "player(s)". The UI would read better with proper plurals from the server.
