# 06 · QA checklist

For the owner's test pass against a real deployment. The prototype uses
fake data, so everything below should be checked against the running bot.
Check each at desktop width and on a phone.

## Before you start
- [ ] `DC_CLIENT_ID`, `DC_CLIENT_SECRET` and an HTTPS `WS_ROOT_URL` are set,
      and `{WS_ROOT_URL}/auth/callback` is registered in the Discord Developer
      Portal.
- [ ] Presence, Server Members and Message Content intents are enabled for
      the bot (see backend notes B1).
- [ ] A test Discord server where you are Administrator, and a second account
      that is a plain member.

## Setup wizard (`/add-bot`)
- [ ] Signed out: "Continue with Discord" signs you in and **returns to the
      wizard** at the invite step, not the home page.
- [ ] Invite opens Discord in a new tab and lists the expected permissions,
      with no Administrator. Adding the bot works.
- [ ] After returning, "Invite opened" shows and Next works.
- [ ] `/channel enable` copied from the wizard works in Discord; the bot replies
      "The bot has been enabled."
- [ ] `/queue create_pickup name:4v4 size:8` works.
- [ ] "Check my server" finds the server (confetti), and "Open settings" lands
      on its overview.
- [ ] With no channel enabled, "Check my server" shows the "No server found
      yet" guidance.
- [ ] Refreshing mid-wizard keeps your step. Clicking stepper nodes moves back
      and forth.
- [ ] With "Reduce motion" on in the OS, the orbs, pulses and confetti stop.

## Dashboard and overview
- [ ] Signed-out and no-server states read correctly and their buttons work.
- [ ] The overview checklist reflects reality. "Show me how" opens the right
      wizard step. Seed ratings, Map profiles and Import history open their
      pages.
- [ ] The server rail "+" and the sidebar's "Enable a channel" / "Create a
      queue" open the wizard at the right step.
- [ ] A server, channel or queue name containing `'` or `"` still opens.

## Settings
- [ ] Every category shows, with descriptions that make sense to a
      non-developer. Note any you'd reword.
- [ ] The info tooltip opens on hover, keyboard focus and tap.
- [ ] Edit two settings in different categories: both keep their values, the
      category dots and "2 unsaved changes" show, and Save stores both. Reload
      to confirm.
- [ ] Discard restores the stored values.
- [ ] Reset (↺) restores a default and marks the row unsaved.
- [ ] A nullable setting switched to "Not set" saves as empty.
- [ ] Ctrl/Cmd+S saves. Leaving or reloading with unsaved changes asks first.
- [ ] Search finds settings by name, description and option text.
- [ ] Renaming a queue saves and the sidebar follows.
- [ ] Tables (maps, aliases, ranks): add, remove, save, reload. The ranks
      `role` column with a role name.

## Admin tool pages
- [ ] **Daily quiz:** the status line matches the bot; the local-time line is
      right for your time zone; saving moves or toggles the quiz.
- [ ] **Access & compute:** each visibility choice behaves as described
      (check the leaderboard link from a signed-out browser and as a plain
      member); the replay switch is locked where unavailable.
- [ ] **Diagnostics:** problems sort first; fix buttons open the right page.
- [ ] **Seed ratings:** file, one player and team ratings each preview
      correctly; invalid rows explain themselves; Apply never overwrites an
      existing rating.
- [ ] **Link profiles:** a profile owned by another member is flagged and not
      moved.
- [ ] **Import history:** on a channel with matches, blockers show and Import
      is disabled. On an empty test channel, a full import succeeds.
- [ ] Drag-and-drop works on every drop zone.

## Regression
- [ ] Leaderboard, Match Stats, Civ Stats, Strategies and player pages look and
      work as before (only the top bar changed).
- [ ] Phone: the top bar wraps cleanly, the settings drawer opens and closes,
      and wide tables scroll inside their frame.
