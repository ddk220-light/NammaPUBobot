# 01 · Design principles

The admin area has three jobs, and each gets a different tone.

| Surface | Job | Tone |
| --- | --- | --- |
| Setup wizard (`/add-bot`) | Get a stranger from "never heard of it" to a working queue | Confident, a little showy, guiding |
| Overview and settings | Let an admin understand and change what the bot does | Calm, scannable, explanatory |
| Admin tool pages | One-off, consequential jobs: imports, access, checks | Plain, careful, precise |

## 1. Explain in the admin's words, not the code's

- Every setting shows its description as visible text under its name. The
  info icon holds the secondary facts (default value, accepted format, the
  equivalent Discord command, what each option means). Nothing an admin needs
  to make a decision is hidden behind hover.
- Labels are sentence case, describe the effect, and avoid internal names:
  "Remove players who go AFK", not `remove_afk`; "Default queue", not
  "is default". The internal key appears only in the tooltip, as part of the
  `/channel set` command, for admins who also use Discord.
- Status words are human: "Unchanged", "Not a member", "No team rating",
  never `existing`, `not_member`, `no_team_rating`.
- When something is unused or unavailable, say so plainly ("Currently unused:
  the promote command was removed"). An honest dead setting is better than a
  description of behaviour that no longer happens.

## 2. Show consequences before they happen

- Imports are three numbered steps, **Destination → Source → Review and
  apply**. Nothing is written until the final button, and the button names the
  exact outcome: "Apply 3 ratings", "Link 2 profiles", "Import 3,338 matches".
- The rules that protect data ("It never overwrites an existing rating", the
  four conditions for a history import) sit next to the action they govern,
  not in a help page.
- Settings edits are collected, counted ("2 unsaved changes") and saved
  together. Leaving with unsaved edits asks first.
- Only changed settings are sent on save, so saving one category can never
  rewrite another.

## 3. Don't look machine-made

The owner asked for the tool pages not to look AI-generated. In practice that
means avoiding the usual tells:

- **No** gradients, glows, glassmorphism, sparkle icons or emoji on working
  pages. (The wizard keeps a gradient hero and animated mark on purpose: it is
  the one marketing moment.)
- **No** decorative icon on every heading. Icons appear where they carry
  meaning: status marks, category navigation, file drop zones.
- **No** grids of identical cards for things that are really a list. Settings
  and checks are ruled rows; a table is a table.
- **No** pill badges for everything. Status is a small coloured dot plus a
  word; pills are kept for the few places a status must stand alone.
- **Real** field labels above or beside inputs, never placeholder-only fields.
- **Specific** copy with real numbers and nouns ("7 of 22 active players have
  no linked profile"), not generic reassurance.
- Left-aligned text, a readable measure (about 60–70 characters for
  paragraphs), and consistent rhythm instead of everything centred.

## 4. One system, three densities

All surfaces share the same tokens (`designs/tokens.css`), type scale and
components. What changes is density and ornament: the wizard is spacious and
animated, settings are medium density with a sidebar, tool pages are narrow
(880 px) single columns built for careful reading.

## 5. Phone-first fallbacks, desktop-first layout

Admins mostly configure on desktop, but they check on phones. Every screen
collapses to one column at 640 px: label rows stack, category navigation
becomes a horizontal strip, the server sidebar becomes a drawer, wide tables
scroll horizontally inside their frame (never the page).

## 6. Accessible by default

- Every control has a visible or `aria` label; switches are real checkboxes.
- Focus is always visible (3px accent ring).
- Colour is never the only signal: every status dot has a word next to it.
- Motion respects `prefers-reduced-motion` (the wizard's orbs, pulses and
  confetti switch off).
