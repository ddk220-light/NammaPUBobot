# 07 · Mobile and tablet

The phone layout is designed for one-handed use, not shrunk from desktop.
Admins mostly configure on a computer, but they check things, flip a switch
or run an import from their phone. Every admin screen has to work there
without sideways scrolling, without hover, and without tiny targets.

**See it:** open `designs/mobile-board.html` (every screen running live in
phone frames, with 360 / 390 / 430 widths), or `designs/prototype.html` in a
narrow window. Renders are in `screens/mobile-design/` for `phone-390` (all 27
states), `phone-360`, `phone-430` and `tablet-768`.

## Breakpoints

| Width | Layout |
| --- | --- |
| > 900px | Desktop: top-bar links with labels, server rail, channel sidebar, two-column settings rows |
| 641–900px | Tablet: icon-only top-bar links, no version chip or username, no server rail (the sidebar has its own server switcher), settings rows stacked |
| ≤ 640px | Phone: everything below |

## Phone frame (D = desktop element, P = phone replacement)

```
┌──────────────────────────────┐
│ ▣ NammaAoE2Bot     (D) (⊕) ⇥ │  top bar, one row, 52px + safe area
├──────────────────────────────┤
│ ☰  Namma AoE2 › #pickups     │  context bar, sticky (dashboard only)
├──────────────────────────────┤
│ (General)(Auto-remove)(Rat…  │  category strip, sticky (settings only)
│                              │
│   …scrolling content…        │
│                              │
│ ┌──────────────────────────┐ │
│ │ ! 2 unsaved  [Discard][✓]│ │  save bar / apply bar, above the tabs
│ └──────────────────────────┘ │
├──────────────────────────────┤
│  🏆     📈     ⚑     ◎     ⚙  │  tab bar, 60px + safe area
└──────────────────────────────┘
```

| Desktop | Phone |
| --- | --- |
| Top-bar text links | **Bottom tab bar** `#tabbar` (Ladder, Matches, Civs, Strategies, Settings; "Ladder" because "Leaderboard" doesn't fit a 72px tab on a 360px phone, and it's the AoE community's word for it). The top bar keeps brand, an icon-only **Add to Discord**, avatar and log in/out |
| Server rail + channel sidebar | **Context bar** (the breadcrumb, sticky, with ☰) opens a **drawer** (`#guild_menu`, up to 320px or 86vw): server switcher (`.gm_servers`), Overview, channels, queues, "Create a queue", "Enable a channel". Tapping outside closes it |
| Page breadcrumbs on tool pages (`.ap-crumb`) | Hidden; the context bar already shows the server, and its name goes back to the overview |
| Category sidebar | Sticky, horizontally scrolling **category chips** under the context bar; a gold dot marks unsaved edits |
| Settings row (label left, control right) | Title + ⓘ + reset ↺ on one line, description, then the full-width control. **On/off settings put the switch beside the title**, like a phone's settings app, and drop reset (it would just be the other position) |
| Hover tooltip | **Bottom sheet** above the tab bar, titled with the setting name; opens on tap (focus), closes on tapping elsewhere |
| Save bar centred at the bottom | Full width, above the tab bar |
| Preview tables | **One card per row**: name and ID with the line number top right, labelled values in two columns, then the result under a rule. Bad rows get a red border |
| Sticky apply footer | Same, above the tab bar; the source note wraps to its own line, and Discard / Apply split the width |
| Wizard stepper | Sticky under the top bar, dots only; hero is full-bleed; chips scroll sideways; the primary action is first and full width, Back below it |
| Overview hero | No server icon (the context bar shows it); a small ring top right; actions become a sideways-scrolling row |
| Health tiles | Two per row |
| File drop zones | No "or drop it here" on touch screens (`pointer: coarse`); tapping opens the picker |

## Rules

- **Touch targets** are at least 44px tall: buttons, drawer rows, tabs, ☰.
  The ⓘ button is 28px with a larger visual hit area; don't shrink it.
- **Inputs are 16px.** iOS zooms the page into any focused field smaller than
  16px. This applies to `.cfg-input`, `.cfg-select`, `.cfg-textarea`, search,
  and table cell inputs.
- **Pinch-zoom is allowed.** The viewport is
  `width=device-width, initial-scale=1, viewport-fit=cover`. Don't add
  `user-scalable=no`.
- **Safe areas:** the top bar adds `env(safe-area-inset-top)`, and the tab
  bar, save bar, toasts and bottom sheets add `env(safe-area-inset-bottom)`.
  `viewport-fit=cover` is what makes those values non-zero on notched phones.
- **The scroll area stops above the tab bar.** `#main_area` is
  `100dvh − top bar − tab bar − safe areas`, which is what lets
  `position: sticky; bottom: 0` footers sit above the tabs. Don't pad
  `#main_area` for the tab bar instead; sticky footers would then hide under
  it.
- **No sideways page scroll, ever.** Anything wider (chip rows, the category
  strip, the overview actions) scrolls inside its own row with a hidden
  scrollbar.
- **Fixed elements and animations:** an element with a running or
  fill-applied `transform` becomes the containing block for `position: fixed`
  children. Entrance animations therefore use `animation-fill-mode: backwards`
  (never `both` or `forwards`), so bottom sheets and the save bar stay
  attached to the viewport.
- Long names truncate with an ellipsis in the context bar and drawer; IDs
  stay monospace and are allowed to break.

## Implementation map

| Piece | Where |
| --- | --- |
| Tab bar markup | `<nav id="tabbar">` after the title bar in `page.html`; `showPage` highlights both `.tb-link[data-page]` and `.tab-link[data-page]` |
| Context bar | `renderBreadcrumb()`: always rendered once a server is selected; `.bc-menu` calls `toggleMobileMenu()`; `.is-root` (no channel) is hidden on desktop |
| Drawer server switcher | `renderGuildMenu()`: the `.gm_servers` row, shown at ≤ 900px |
| Inline switches | `renderVariable()` adds `.is-bool`; the phone CSS turns `.cfg-control` into `display: contents` and places the parts on the row grid |
| Bottom-sheet title | `settingTip()` emits `.tip-title` (hidden on desktop) |
| Card tables | Cells carry `data-label` and `cell-who`, `cell-line`, `cell-wide`, `cell-result` classes in the four preview renderers |
| Touch drop zones | `apDrop(id, accept, title, limits)` prefixes "or drop it here" only for fine pointers |
| All phone CSS | One block, "Phone layout", at the end of the `<style>` element; tablet rules in its `@media (max-width: 900px)` |

## Mobile QA (add to `06-qa-checklist.md` runs)

- [ ] iPhone (Safari) and Android (Chrome), portrait. Nothing scrolls
      sideways on any screen.
- [ ] Tab bar: correct tab highlighted on every page, clear of the home
      indicator.
- [ ] ☰ opens the drawer. Switching server, channel and queue closes it.
      Tapping the dimmed area closes it.
- [ ] Settings: the category strip stays under the context bar while
      scrolling. Switches toggle from the row. ⓘ opens a bottom sheet;
      tapping elsewhere closes it.
- [ ] Focusing any field does **not** zoom the page (iOS).
- [ ] The unsaved bar and the import apply bar sit above the tab bar and
      never cover the last setting or row.
- [ ] Import previews show as cards; a 500-row preview stays smooth.
- [ ] File pickers open the phone's file chooser; the chosen name shows.
- [ ] Wizard: the stepper stays visible while scrolling; "Add to Discord"
      opens the Discord app or site; returning to the browser keeps the
      step.
- [ ] Landscape phone (≈ 844 × 390) uses the tablet layout and still works.
- [ ] iPad portrait: sidebar visible, settings rows stacked, top bar fits.
