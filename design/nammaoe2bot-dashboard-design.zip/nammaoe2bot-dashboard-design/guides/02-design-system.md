# 02 · Design system

All values live as CSS custom properties on `:root` in
`nammaoe2bot/web/page.html` (copied to `designs/tokens.css`). Use the tokens;
don't introduce new hex values on admin surfaces.

## Colour

| Token | Value | Use |
| --- | --- | --- |
| `--ui-bg` | `#313338` | Page background for dashboard and wizard |
| `--ui-sunken` | `#1e1f22` | Inputs, code samples, server rail |
| `--ui-panel` | `#2b2d31` | Panels, lists, sidebar, table headers |
| `--ui-raised` | `#383a40` | Hover fills, letter avatars |
| `--ui-line` / `--ui-line-strong` | 7% / 13% white | Row rules / panel borders, input borders |
| `--ui-text` | `#f2f3f5` | Titles, labels, values |
| `--ui-body` | `#dbdee1` | Body copy |
| `--ui-muted` | `#a8acb3` | Help text, descriptions |
| `--ui-faint` | `#80848e` | Notes, metadata, IDs, captions |
| `--ui-accent` (+ `-hi`, `-soft`) | `#5865f2` | Primary buttons, focus, selection. Discord blurple, so the product sits naturally next to Discord |
| `--ui-gold` (+ `-soft`) | `#e4b54a` | Brand mark, queue identity, "unsaved" markers. AoE2 gold; use sparingly |
| `--ui-ok` / `--ui-warn` / `--ui-danger` (+ `-soft`) | green / amber / red | Status only. Never decorative |

Rules: one accent per view. Gold marks either the brand or "you changed
this"; it is never a second button colour. Status colours always come with a
word.

## Type

- **Outfit** for all UI text; **Oswald 500** for page and section titles that
  name a place (page `h1`, settings category titles, wizard headings).
- Weights: 400 body, 600 labels and emphasis, 500 for Oswald titles. Avoid 700+
  except the wizard hero.
- Scale (rem at a 15px root): 0.72 eyebrows and table headers · 0.82–0.88 help,
  notes · 0.92–0.98 body, field labels · 1.05–1.3 section titles · 1.65–1.75
  page titles · 2.6 wizard hero.
- Monospace (`--ui-mono`) only for IDs, commands, file names and CSV samples.
- The page has a legacy global rule `* { font-size: 15px; font-family: Outfit }`.
  The redesigned surfaces opt out with a zero-specificity
  `:where(...) * { font-size: inherit; font-family: inherit }` reset. **Add any
  new admin surface's root class to that list**, or nested text will snap to
  15px.

## Spacing and layout

- Rhythm: 0.35 · 0.6 · 0.9 · 1.1 · 1.5 · 2.2 rem.
- Radius: 8px small controls and code, 10px inputs and callouts, 12–16px
  panels, 18–22px hero surfaces, 999px pills and switches.
- Content widths: tool pages 880px · settings 1100px · overview 1120px ·
  wizard 1040px.
- Breakpoints: **900px** hides the server rail, collapses settings navigation
  to a horizontal strip, stacks wizard cards; **640px** stacks every label row,
  turns the channel sidebar into a drawer, hides top-bar labels.

## Components

Class names are the ones in `page.html`.

### Buttons: `.ui-btn`
Variants: default (accent), `.ghost` (secondary), `.success` (the final
"apply" action), `.discord` (gradient, wizard and sign-in only), `.big`.
Icon before or after the label at 16px. Disabled is 42% opacity, no hover.
`.setup-action` is the compact accent button used inside overview rows.

### Status
- `.ap-dot` + word: the default status display (`.ok`, `.warn`, `.bad`).
- `.overview-badge.<status>`: a pill, used only where a status stands alone
  (checklist rows, feature cards).
- `statusTone(status)` and `sentenceLabel(status)` in JS map API status codes
  to tone and words. Add new codes there, not inline.

### Settings row: `.cfg-var`
Two columns: name + info tooltip + description on the left, control + reset
button on the right. `.wide` puts tables and long text full width. When edited
it gets `.is-dirty`: a gold left rule and an "Unsaved" tag.

### Controls
- `.cfg-switch`: an on/off switch around a real checkbox. The `.state`
  label reads from `data-on` / `data-off`, so the word always matches.
- Nullable settings: a "Not set / Custom value" switch revealing the input.
- `.cfg-input`, `.cfg-select` (custom chevron), `.cfg-textarea`, `.cfg-range`
  (slider and number kept in sync).
- `.editable_table` for list settings (maps, aliases, ranks): add and remove
  rows inline, with an empty state.

### Info tooltip: `.info-tip`
An 18px "i" button. Opens on hover and keyboard focus, so it works on touch by
tapping. It contains: default value, format, the equivalent `/channel set` or
`/queue set` command, and for option settings what each option does.

### Save bar: `.cfg-savebar`
Fixed to the bottom centre of the viewport. Hidden until something changes.
Shows the count, Discard and Save. It nudges if you try to leave with unsaved
changes and the browser prompt is refused. Ctrl/Cmd+S saves. It must sit
**outside** any animated container, because an element with a transform
becomes the containing block for `position: fixed`.

### Tool page kit: `.ap-*`
- `.ap-crumb` breadcrumb (server name › page), `.ap-head` (title, one-sentence
  lede, optional status or action on the right).
- `.ap-section` with a numbered title (`.ap-step-no`).
- `.ap-row`: label + help on the left, field on the right; stacks on phones.
- `.ap-choice`: radio cards where each option explains its consequence.
- `.ap-tabset` / `.ap-tabs`: underline tabs for alternative sources. Panels
  are hidden, not re-rendered, so typed values and chosen files survive.
- `.ap-drop`: file drop zone. A transparent `<input type=file>` covers it, so
  click and drag both work; it shows the chosen file's name and size.
- `.ap-sample`: a monospace example of the expected file.
- `.ap-rules`: the short list of guarantees next to an action.
- `.ap-callout` (`.ok`, `.bad`): blockers and passes.
- `.ap-counts`: an inline summary ("5 rows · 3 ready · 1 invalid"), coloured
  only when non-zero.
- `.ap-table`: sticky header, numeric columns right-aligned, `.who` cell (name
  over monospace ID), `.result` cell (dot, word, explanation).
- `.ap-foot`: sticky action bar (context on the left, Discard and Apply on the
  right).
- `.ap-empty`: dashed placeholder for "nothing to review yet".

### Wizard pieces: `.addbot-*`, `.dc-*`
Hero (gradient, orbs, grid, pulsing mark), the five-node stepper with a
progress track, the step card (text plus a Discord-style preview), copyable
command blocks (`.code-copy`), and `.dc-mock` previews that imitate a Discord
channel, invite or authorise screen.

## Motion

- Easing `--ui-ease` (`cubic-bezier(.2,.8,.2,1)`), 150–300ms for UI, 400–600ms
  for entrances.
- `ui-rise` (fade and lift 10px) for page entrances; the save bar slides up.
- Wizard only: orb drift, ring pulse, logo float, typing caret, confetti when
  the server is found.
- Everything decorative is disabled under `prefers-reduced-motion: reduce`.

## Icons

Inline stroke SVGs (`icon(name)` in JS, 24-unit viewBox, 2px stroke,
`currentColor`), because the content security policy allows no icon font. The
Discord glyph is the only filled icon. Add glyphs to `UI_ICONS`; keep them
single-colour and stroke-based.
