// Mobile design set: drives the prototype at phone and tablet sizes.
// Usage: node tools/capture-mobile.js prototype.html screens-mobile   (needs Playwright + Chromium)
const { chromium } = require('playwright');
const fs = require('fs');
const [PROTO, OUTDIR] = process.argv.slice(2);
const html = fs.readFileSync(PROTO, 'utf8');
const DEVICES = {
  'phone-390': { width: 390, height: 844 },   // iPhone 13–15
  'phone-360': { width: 360, height: 780 },   // small Android
  'phone-430': { width: 430, height: 932 },   // iPhone Pro Max
  'tablet-768': { width: 768, height: 1024 }  // iPad portrait
};
// [file, prototype screen, action, full-length?]
const PHONE = [
  ['01-wizard-sign-in', 'wizard-signed-out'], ['02-wizard-invite', 'wizard-invite'],
  ['03-wizard-invite-step', 'wizard-invite', 'card'], ['04-wizard-enable-channel', 'wizard-enable-channel', 'card'],
  ['05-wizard-create-queue', 'wizard-create-queue', 'card'], ['06-wizard-all-set', 'wizard-check', 'card'],
  ['07-dashboard-signed-out', 'dashboard-signed-out'], ['08-dashboard-no-servers', 'dashboard-no-servers'],
  ['09-overview', 'overview'], ['10-overview-full', 'overview', null, true], ['11-drawer', 'channel-settings', 'drawer'],
  ['12-channel-settings', 'channel-settings'], ['13-settings-switches', 'channel-settings', 'tab:Auto-remove'],
  ['14-settings-unsaved', 'channel-settings', 'dirty'], ['15-settings-info-sheet', 'channel-settings', 'sheet'],
  ['16-settings-search', 'channel-settings', 'search'], ['17-queue-settings-full', 'queue-settings', null, true],
  ['18-queue-maps-table', 'queue-settings', 'tab:Maps'], ['19-daily-quiz', 'daily-quiz'], ['20-access-compute', 'access-compute'],
  ['21-diagnostics', 'diagnostics'], ['22-seed-ratings', 'seed-ratings'], ['23-seed-ratings-review', 'seed-ratings', 'seedpreview'],
  ['24-seed-ratings-review-full', 'seed-ratings', 'seedpreview', true], ['25-team-ratings-review-full', 'seed-ratings', 'teampreview', true],
  ['26-link-profiles-review-full', 'link-profiles', 'idpreview', true], ['27-import-history-full', 'import-history', 'migpreview', true]
];
const SUBSET = ['02-wizard-invite', '09-overview', '12-channel-settings', '14-settings-unsaved', '23-seed-ratings-review'];
const SHOTS = {
  'phone-390': PHONE,
  'phone-360': PHONE.filter(s => SUBSET.includes(s[0])),
  'phone-430': PHONE.filter(s => SUBSET.includes(s[0])),
  'tablet-768': [['01-wizard-invite', 'wizard-invite'], ['02-overview', 'overview'], ['03-channel-settings', 'channel-settings'], ['04-seed-ratings-review', 'seed-ratings', 'seedpreview']]
};
(async () => {
  const browser = await chromium.launch();
  for (const [device, list] of Object.entries(SHOTS)) {
    const size = DEVICES[device];
    fs.mkdirSync(`${OUTDIR}/${device}`, { recursive: true });
    for (const [file, screen, action, full] of list) {
      const page = await browser.newPage({ viewport: size, deviceScaleFactor: 2, isMobile: device !== 'tablet-768', hasTouch: true });
      page.on('pageerror', e => console.log('PAGEERROR', device, file, e.message));
      await page.route('**/*', r => new URL(r.request().url()).hostname === 'localhost'
        ? r.fulfill({ status: 200, contentType: 'text/html', body: html }) : r.abort());
      await page.goto(`http://localhost/#${screen}`);
      await page.waitForTimeout(1600);
      await page.addStyleTag({ content: '#proto-panel{display:none!important}' });
      const upload = (id, name) => page.setInputFiles('#' + id, { name, mimeType: 'text/csv', buffer: Buffer.from('user_id,rating\n1,1500\n') });
      if (action === 'card') await page.evaluate(() => { const c = document.querySelector('.addbot-stepper'); document.getElementById('main_area').scrollTop = c.offsetTop; });
      if (action === 'drawer') await page.evaluate(() => toggleMobileMenu());
      if (action === 'dirty') { await page.evaluate(() => switchTab('Auto-remove')); await page.click('.cfg-var[data-variable="remove_offline"] .cfg-switch'); await page.click('.cfg-var[data-variable="expire_time"] .cfg-switch'); await page.fill('[data-var="expire_time"]', '2h'); }
      if (action === 'sheet') { await page.evaluate(() => switchTab('Rating')); await page.focus('.cfg-var[data-variable="rating_system"] .info-tip button'); }
      if (action === 'search') await page.fill('#settings-search', 'remove');
      if (action && action.startsWith('tab:')) await page.evaluate(t => switchTab(t), action.slice(4));
      if (action === 'seedpreview') { await upload('seed-upload', 'players.csv'); await page.evaluate(() => previewFileRatingSeed()); }
      if (action === 'teampreview') { await page.click('.ap-tabs button[data-tab="team"]'); await page.evaluate(() => previewTeamRatings()); }
      if (action === 'idpreview') { await upload('identity-upload', 'profiles.csv'); await page.evaluate(() => previewIdentityFile()); }
      if (action === 'migpreview') { await upload('migration-upload', 'pubobot-export.zip'); await page.evaluate(() => previewHistoricalMigration()); }
      await page.waitForTimeout(900);
      if (full) {
        // Grow the viewport to the content so the whole page is in one image;
        // the tab bar stays pinned to the bottom edge as on a real phone.
        const h = await page.evaluate(() => document.getElementById('main_area').scrollHeight);
        const chrome = size.height - await page.evaluate(() => document.getElementById('main_area').clientHeight);
        await page.setViewportSize({ width: size.width, height: Math.min(h + chrome, 6000) });
        await page.evaluate(() => { document.getElementById('main_area').scrollTop = 0; });
        await page.waitForTimeout(400);
      }
      await page.screenshot({ path: `${OUTDIR}/${device}/${file}.png` });
      await page.close();
    }
  }
  await browser.close();
})();
