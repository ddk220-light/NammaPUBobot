import json, sys
page, mock, vars_path, out = sys.argv[1:5]
html = open(page).read()
js = open(mock).read().replace('__VARS__', json.dumps(json.load(open(vars_path)), ensure_ascii=False))
anchor = '<script>\n/* ─── State ─── */'
assert html.count(anchor) == 1
html = html.replace(anchor, '<script>\n' + js + '\n</script>\n' + anchor)
html = html.replace('<title>NammaAoE2Bot</title>', '<title>NammaAoE2Bot · design prototype</title>')
open(out, 'w').write(html)
