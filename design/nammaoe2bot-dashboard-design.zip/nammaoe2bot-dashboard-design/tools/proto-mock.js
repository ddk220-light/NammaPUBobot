/* ═══ PROTOTYPE ONLY ═══════════════════════════════════════════════════════
   Everything between these banners is injected by the design package's build
   step and is NOT part of nammaoe2bot/web/page.html. It replaces fetch() with
   a fake API so every admin screen can be clicked through offline, and adds a
   "Screens" switcher in the bottom-left corner. Setting metadata (names,
   descriptions, types, defaults, options) is extracted from
   nammaoe2bot/pickup/channel.py and queue.py, so it matches the real bot.
   ═════════════════════════════════════════════════════════════════════════ */
(function () {
  var VARS = __VARS__;
  var PROTO = window.PROTO = { auth: true, communities: true };
  var invite = 'https://discord.com/oauth2/authorize?client_id=123456789012345678&scope=bot+applications.commands&permissions=268815424';

  function sampleValues(kind) {
    var v = JSON.parse(JSON.stringify(VARS[kind].variables));
    if (kind === 'channel') {
      v.rating_initial.value = 1500; v.lb_min_matches.value = 10;
      v.ranks.value = (v.ranks.default || []).map(function (r) { return { rank: r.rank, rating: String(r.rating), role: '' }; });
      v.description.value = 'Ranked AoE2 team games. Type ++ to join, -- to leave.';
    } else {
      v.name.value = '4v4'; v.size.value = 8; v.ranked.value = 'on'; v.team_size.value = 4;
      v.team_names.value = 'Rise Fall';
      v.maps.value = ['Arabia', 'Arena', 'Black Forest', 'Nomad', 'Hideout'].map(function (n) { return { name: n }; });
      v.aliases.value = [{ alias: 'team' }];
      v.start_msg.value = 'Lobby password is in the pins. GLHF!';
    }
    return v;
  }

  var overview = {
    community: { id: '9', name: 'Namma AoE2' },
    onboarding: { completed_required: 2, required_steps: 3, steps: [
      { key: 'channels', title: 'Connect a pickup channel', status: 'complete', required: true, detail: '1 configured channel(s) are loaded in this community.' },
      { key: 'queues', title: 'Create a pickup queue', status: 'complete', required: true, detail: '2 queue(s) are available across the loaded channels.' },
      { key: 'history', title: 'Migrate historical matches (optional)', status: 'recommended', required: false, detail: 'Import a complete Pubobot export before this community starts playing.', action: 'migrate_history' },
      { key: 'ratings', title: 'Seed player ratings', status: 'required', required: true, detail: '0 player(s) currently have a seeded rating.', action: 'seed_ratings' },
      { key: 'identities', title: 'Link Discord users to AoE2 profiles', status: 'recommended', required: false, detail: '3 player(s) are linked to 3 AoE2 profile(s).', action: 'map_identities' } ] },
    capabilities: [
      { key: 'pickup', title: 'Pickup games', status: 'active', scope: 'community', configurable: true, summary: 'Queue formation, check-in and match reporting.', metrics: { channels: 1, queues: 2 } },
      { key: 'ratings', title: 'Ratings', status: 'setup_required', scope: 'channel', configurable: true, summary: 'Per-channel ratings for ranked queues.', metrics: { players: 0 } },
      { key: 'predictions', title: 'Flash predictions', status: 'partial', scope: 'queue', configurable: true, summary: 'Audience gold betting on ranked matches.', metrics: {} },
      { key: 'gold', title: 'Gold economy', status: 'available', scope: 'community', configurable: false, summary: 'Automatic balances used by predictions and quiz rewards.', metrics: { holders: 0 } },
      { key: 'quiz', title: 'Daily quiz', status: 'active', scope: 'community', configurable: true, summary: 'Scheduled AoE2 quiz posts and rewards.', metrics: { channel: 'pickups' } },
      { key: 'lobby', title: 'Lobby tracking', status: 'available', scope: 'built_in', configurable: false, summary: 'Automatic lobby detection and API-confirmed game starts.', metrics: {} } ],
    diagnostics: { status: 'healthy', discord_connected: true, bot_ready: true, channel_consistency: { loaded: 1 }, data: { players: 0, linked_profiles: 3, matches: 120, parsed_replays: 0 } }
  };

  var GET = {
    '/api/me': function () {
      return PROTO.auth
        ? { logged_in: true, oauth_enabled: true, user_id: '1', username: 'Deepak', avatar: null, csrf: 'proto', invite_url: invite }
        : { logged_in: false, oauth_enabled: true, invite_url: invite };
    },
    '/api/admin/communities': function () { return { communities: PROTO.communities ? [{ id: '9', name: 'Namma AoE2', channels: 1, icon: null }] : [] }; },
    '/api/admin/communities/9': function () { return { community: { id: '9', name: 'Namma AoE2', channels: 1, icon: null } }; },
    '/api/admin/communities/9/overview': function () { return overview; },
    '/api/admin/communities/9/channels': function () { return { channels: [{ id: '55', name: 'pickups' }] }; },
    '/api/admin/communities/9/policy': function () {
      return { policy: { dashboard_visibility: 'public', allowed_dashboard_visibilities: ['public', 'members', 'admins'], replay_analysis_requested: false, replay_reason: 'community_disabled' },
        deployment: { mode: 'self_hosted', replay_available: true } };
    },
    '/api/admin/communities/9/quiz': function () {
      return { channels: [{ id: '55', name: 'pickups', enabled: true, quiz_hour: 18, open_window: 86400 }], active_channel_id: '55' };
    },
    '/api/admin/communities/9/diagnostics': function () {
      return { community: { name: 'Namma AoE2' }, status: 'warning', summary: { critical: 1, warnings: 1 }, checks: [
        { key: 'channels', title: 'Discord channel consistency', status: 'ok', detail: 'Every enrolled channel is loaded and visible to the bot.', metrics: { enrolled: 1, loaded: 1 } },
        { key: 'identities', title: 'Recent identity coverage', status: 'warning', detail: '7 of 22 players active in the last 30 days have no linked AoE2 profile.', metrics: { active_players: 22, unlinked: 7 }, action: { target: 'map_identities', label: 'Map profiles' } },
        { key: 'gold', title: 'Gold ledger integrity', status: 'critical', detail: '2 cached balances disagree with the ledger.', metrics: { mismatches: 2 } },
        { key: 'quiz', title: 'Quiz configuration', status: 'ok', detail: 'One quiz channel is enabled.', metrics: { enabled: 1 } },
        { key: 'deployment', title: 'Deployment boundary', status: 'ok', detail: 'Self-hosted; replay analysis is off for this community.', metrics: {}, action: { target: 'access_policy', label: 'Access settings' } } ] };
    },
    '/api/admin/communities/9/channels/55/config': function () {
      return { sections: VARS.channel.sections, variables: sampleValues('channel'), is_admin: true, channel_name: 'pickups' };
    },
    '/api/admin/communities/9/channels/55/queues': function () { return { queues: [{ name: '4v4' }, { name: '1v1' }] }; },
    '/api/admin/communities/9/channels/55/queues/4v4/config': function () {
      return { sections: VARS.queue.sections, variables: sampleValues('queue'), is_admin: true, queue_name: '4v4' };
    }
  };
  GET['/api/admin/communities/9/channels/55/queues/1v1/config'] = function () {
    var r = GET['/api/admin/communities/9/channels/55/queues/4v4/config']();
    r.variables.name.value = '1v1'; r.variables.size.value = 2; r.variables.team_size.value = 1; return r;
  };

  var POST = [
    ['/ratings/seed/preview', { source: 'players.csv', can_apply: true, digest: 'proto', target: { pickup_channel_id: '55', rating_channel_id: '55', rating_channel_name: 'pickups' },
      summary: { received: 5, ready: 3, new: 3, existing: 1, invalid: 1 }, rows: [
        { line: 2, user_id: '183736495620112384', nick: 'Hera', rating: 1840, deviation: 120, status: 'ready', message: 'New player; will be added.' },
        { line: 3, user_id: '219874560321789952', nick: 'Tatoh', rating: 1712, deviation: 120, status: 'ready', message: 'New player; will be added.' },
        { line: 4, user_id: '301928374650918273', member_name: 'Viper', rating: 1655, deviation: 200, status: 'ready', message: 'Uses the channel deviation.' },
        { line: 5, user_id: '412093847561029384', nick: 'Arthas', rating: 1501, deviation: 120, status: 'existing', message: 'Already rated 1534; left unchanged.' },
        { line: 6, user_id: 'abc', rating: 'high', status: 'invalid', message: 'user_id must be a Discord ID; rating must be a number.' } ] }],
    ['/ratings/seed/aoe-team/preview', { source: 'AoE2 ranked team ladder', can_apply: true, digest: 'proto', selection_policy: 'The highest current team rating across linked profiles is used.',
      target: { pickup_channel_id: '55', rating_channel_id: '55', rating_channel_name: 'pickups', initial_deviation: 200 },
      summary: { linked_users: 4, profiles: 5, ready: 2, existing: 1, no_team_rating: 1, unavailable: 0 }, blockers: [], rows: [
        { user_id: '183736495620112384', member_name: 'Hera', profiles: [{ profile_id: '2583713', name: 'Hera', rating: 2210 }], profile_id: '2583713', rating: 2210, status: 'ready', message: 'Will be seeded.' },
        { user_id: '219874560321789952', member_name: 'Tatoh', profiles: [{ profile_id: '196240', name: 'TaToH', rating: 1980 }, { profile_id: '196241', name: 'TaToH smurf', rating: 1610 }], profile_id: '196240', rating: 1980, status: 'ready', message: 'Highest of 2 profiles.' },
        { user_id: '301928374650918273', member_name: 'Viper', profiles: [{ profile_id: '199325', name: 'TheViper', rating: 2105 }], profile_id: '199325', rating: 2105, status: 'existing', message: 'Already rated; left unchanged.' },
        { user_id: '412093847561029384', member_name: 'Arthas', profiles: [{ profile_id: '771234', name: 'Arthas', rating: null, status: 'no_team_rating' }], status: 'no_team_rating', message: 'No ranked team games on record.' } ] }],
    ['/migration/pubobot/preview', { source: 'pubobot-export.zip', timezone: 'Asia/Kolkata', can_apply: false, digest: 'proto', target: { channel_id: '55', channel_name: 'pickups' },
      summary: { matches: 3338, players: 214, player_matches: 26704, rating_history: 26704 },
      preflight: { blockers: ['#pickups already has 120 recorded matches.', 'A match is in progress in #pickups.'] } }],
    ['/identities/import/preview', { source: 'profiles.csv', can_apply: true, digest: 'proto', name_policy: 'Imported names are review labels only; stored names update when a player is seen in a game.',
      summary: { received: 4, ready: 2, new: 2, existing: 1, conflict: 1 }, rows: [
        { line: 2, user_id: '183736495620112384', member_name: 'Hera', profile_id: '2583713', aoe2_name: 'Hera', status: 'ready', message: 'Will be linked.' },
        { line: 3, user_id: '219874560321789952', member_name: 'Tatoh', profile_id: '196240', aoe2_name: 'TaToH', status: 'ready', message: 'Will be linked.' },
        { line: 4, user_id: '301928374650918273', member_name: 'Viper', profile_id: '199325', aoe2_name: 'TheViper', status: 'existing', message: 'Already linked to this member.' },
        { line: 5, user_id: '412093847561029384', member_name: 'Arthas', profile_id: '2583713', aoe2_name: 'Hera', status: 'conflict', message: 'Profile belongs to another member; not moved.' } ] }],
    ['/apply', { ok: true, applied: 3, matches: 3338 }],
    ['/config', { ok: true }],
    ['/policy', null],
    ['/quiz', null]
  ];

  function respond(body, status) {
    return new Promise(function (resolve) {
      setTimeout(function () {
        resolve(new Response(JSON.stringify(body), { status: status || 200, headers: { 'Content-Type': 'application/json' } }));
      }, 250);
    });
  }

  window.fetch = function (input, opts) {
    var url = new URL(typeof input === 'string' ? input : input.url, 'http://proto.local');
    var method = ((opts && opts.method) || 'GET').toUpperCase();
    if (method === 'GET' && GET[url.pathname]) return respond(GET[url.pathname]());
    if (method === 'POST') {
      for (var i = 0; i < POST.length; i++) {
        if (url.pathname.slice(-POST[i][0].length) === POST[i][0]) {
          if (POST[i][1] === null) return respond(GET[url.pathname]());
          return respond(POST[i][1]);
        }
      }
    }
    return respond({ error: 'Not part of the prototype' }, 404);
  };

  // file:// pages may not push real paths; keep the URL and carry on.
  ['pushState', 'replaceState'].forEach(function (fn) {
    var original = history[fn].bind(history);
    history[fn] = function (state, title, url) {
      try { return original(state, title, url); } catch (e) { try { return original(state, title); } catch (_e) {} }
    };
  });

  function waitFor(test, done) {
    var tries = 0;
    (function tick() { if (test()) return done(); if (++tries < 80) setTimeout(tick, 50); })();
  }

  function dashboard(then) {
    dashDirty = {};
    PROTO.auth = true; PROTO.communities = true;
    checkAuth().then(function () {
      dashOverviewData = null;
      if (currentPage === 'dashboard') loadDashboard(); else showPage('dashboard');
      waitFor(function () { return !!dashOverviewData; }, then || function () {});
    });
  }

  var SCREENS = {
    'wizard-signed-out': function () { PROTO.auth = false; resetWizard(); checkAuth().then(function () { showPage('add-bot'); }); },
    'wizard-invite': function () { PROTO.auth = true; resetWizard(); checkAuth().then(function () { addBotStep = 1; showPage('add-bot'); }); },
    'wizard-enable-channel': function () { wizardAt(2); },
    'wizard-create-queue': function () { wizardAt(3); },
    'wizard-check': function () { wizardAt(4); },
    'dashboard-signed-out': function () { PROTO.auth = false; checkAuth().then(function () { showPage('dashboard'); }); },
    'dashboard-no-servers': function () { PROTO.auth = true; PROTO.communities = false; checkAuth().then(function () { publicCommunityId = null; showPage('dashboard'); }); },
    'overview': function () { dashboard(); },
    'channel-settings': function () { dashboard(function () { selectChannelAt(0); }); },
    'queue-settings': function () { dashboard(function () { selectChannelAt(0); waitFor(function () { return dashQueues.length; }, function () { selectQueueAt(0); }); }); },
    'daily-quiz': function () { dashboard(function () { openQuizSettings(); }); },
    'access-compute': function () { dashboard(function () { openCommunityPolicy(); }); },
    'diagnostics': function () { dashboard(function () { openCommunityDiagnostics(); }); },
    'seed-ratings': function () { dashboard(function () { openRatingSeed(); }); },
    'link-profiles': function () { dashboard(function () { openIdentityImport(); }); },
    'import-history': function () { dashboard(function () { openHistoricalMigration(); }); }
  };

  function resetWizard() {
    addBotStep = null; addBotInvited = false; addBotFound = null;
    try { sessionStorage.clear(); } catch (e) {}
  }

  function wizardAt(step) {
    PROTO.auth = true; PROTO.communities = true; resetWizard();
    checkAuth().then(function () { addBotStep = step; addBotInvited = true; showPage('add-bot'); if (step === 4) addBotCheck(); });
  }

  window.protoGo = function (name) {
    if (!SCREENS[name]) return;
    try { location.hash = name; } catch (e) {}
    SCREENS[name]();
  };

  window.addEventListener('load', function () {
    var panel = document.createElement('div');
    panel.id = 'proto-panel';
    panel.innerHTML = '<style>#proto-panel{position:fixed;left:12px;bottom:12px;z-index:200;font:13px Outfit,sans-serif;color:#dbdee1;'
      + 'background:#111214;border:1px solid rgba(255,255,255,.14);border-radius:10px;padding:8px 10px;display:flex;gap:8px;align-items:center;box-shadow:0 12px 30px rgba(0,0,0,.6)}'
      + '#proto-panel b{color:#e4b54a;font-weight:600}#proto-panel select{background:#1e1f22;color:#f2f3f5;border:1px solid rgba(255,255,255,.14);border-radius:6px;padding:4px 6px;font:inherit}</style>'
      + '<b>Prototype</b><select aria-label="Jump to screen" onchange="protoGo(this.value)">'
      + Object.keys(SCREENS).map(function (k) { return '<option value="' + k + '">' + k.replace(/-/g, ' ') + '</option>'; }).join('') + '</select>';
    document.body.appendChild(panel);
    var start = (location.hash || '').slice(1) || 'wizard-invite';
    panel.querySelector('select').value = start;
    setTimeout(function () { protoGo(start); }, 150);
  });
})();
/* ═══ END PROTOTYPE ONLY ════════════════════════════════════════════════════ */
