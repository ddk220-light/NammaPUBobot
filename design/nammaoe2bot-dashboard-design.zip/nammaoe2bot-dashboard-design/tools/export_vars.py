"""Extract channel/queue setting metadata from source for the design prototype.

Evaluates each `Variables.XVar(...)` call against stand-ins, so no database,
Discord client or config is needed. Lambdas are never called.
"""
import ast, builtins, json, sys

TYPE = {"StrVar": "str", "EmojiVar": "str", "TextVar": "text", "OptionVar": "option", "BoolVar": "bool",
        "IntVar": "int", "SliderVar": "slider", "DurationVar": "duration", "VariableTable": "table",
        "RoleVar": None, "MemberVar": None, "TextChanVar": None}

class Var:
    def __init__(self, kind, name, *args, **kw):
        self.kind, self.name, self.kw = kind, name, kw
        self.columns = [c.name for c in kw.get("variables", [])] if kind == "VariableTable" else None

class Variables:
    def __getattr__(self, kind):
        return lambda name, *a, **kw: Var(kind, name, *a, **kw)

class Names(dict):
    def __missing__(self, key):
        if hasattr(builtins, key): return getattr(builtins, key)
        if key == "Variables": return Variables()
        if key == "VariableTable": return lambda name, *a, **kw: Var("VariableTable", name, *a, **kw)
        if key in ("seconds_to_str",): return lambda x: str(x)
        if key == "locales": return {"en": None}
        if key == "rating_names": return {"flat": 0, "Glicko2": 0, "TrueSkill": 0, "AoE2": 0}
        return 0

def readable(kind, value):
    if value is None: return None
    if kind == "BoolVar": return "on" if value else "off"
    if kind == "DurationVar":
        h, r = divmod(int(value), 3600); m, s = divmod(r, 60)
        return f"{h:02}:{m:02}:{s:02}" if value else None
    return value

def extract(path):
    tree = ast.parse(open(path).read())
    out, sections = {}, []
    for node in ast.walk(tree):
        is_var = isinstance(node, ast.Call) and node.args and isinstance(node.args[0], ast.Constant) and (
            (isinstance(node.func, ast.Attribute) and isinstance(node.func.value, ast.Name) and node.func.value.id == "Variables")
            or (isinstance(node.func, ast.Name) and node.func.id == "VariableTable"))
        if is_var:
            var = eval(compile(ast.Expression(node), path, "eval"), {"__builtins__": builtins}, Names())
            kind = var.kind
            if TYPE.get(kind) is None or "section" not in var.kw:
                continue
            kw = var.kw
            meta = {"type": TYPE[kind], "display": kw.get("display"), "description": kw.get("description"),
                    "section": kw.get("section"), "notnull": bool(kw.get("notnull", False)),
                    "default": kw.get("default", [] if kind == "VariableTable" else None)}
            meta["value"] = readable(kind, meta["default"]) if kind != "VariableTable" else []
            if kind == "OptionVar": meta["options"] = list(kw.get("options", []))
            if kind == "SliderVar":
                meta["min"], meta["max"], meta["unit"] = kw.get("min_val", 0), kw.get("max_val", 100), kw.get("unit", "%")
            if kind == "VariableTable": meta["columns"] = var.columns
            if var.name in out: continue
            out[var.name] = meta
            if meta["section"] not in sections: sections.append(meta["section"])
    # The factory declares its own tab order; keep it and append any extras.
    for node in ast.walk(tree):
        if isinstance(node, ast.keyword) and node.arg == "sections" and isinstance(node.value, ast.List):
            declared = [e.value for e in node.value.elts]
            sections = declared + [s for s in sections if s not in declared]
    return {"sections": sections, "variables": out}

json.dump({"channel": extract(sys.argv[1]), "queue": extract(sys.argv[2])}, open(sys.argv[3], "w"), indent=1, default=str)
