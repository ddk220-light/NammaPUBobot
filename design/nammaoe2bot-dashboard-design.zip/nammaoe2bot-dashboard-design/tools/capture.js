// Drives the design prototype and screenshots every screen for the package.
// Usage: node tools/capture.js prototype.html screens   (needs Playwright + Chromium)
const { chromium } = require('playwright');
const fs = require('fs');
const [PROTO, OUTDIR] = process.argv.slice(2);
const html = fs.readFileSync(PROTO, 'utf8');
const SHOTS = {
  desktop: [
    ['01-wizard-sign-in', 'wizard-signed-out'], ['02-wizard-invite', 'wizard-invite'], ['03-wizard-enable-channel', 'wizard-enable-channel', 'stepper'],
    ['04-wizard-create-queue', 'wizard-create-queue', 'stepper'], ['05-wizard-all-set', 'wizard-check', 'stepper'],
    ['06-dashboard-signed-out', 'dashboard-signed-out'], ['07-dashboard-no-servers', 'dashboard-no-servers'],
    ['08-overview', 'overview', 'full'], ['09-channel-settings', 'channel-settings'],
    ['10-channel-settings-unsaved', 'channel-settings', 'dirty'], ['11-channel-settings-info-tooltip', 'channel-settings', 'tooltip'],
    ['12-channel-settings-search', 'channel-settings', 'search'], ['13-queue-settings-teams', 'queue-settings', 'teams'],
    ['14-queue-settings-maps-table', 'queue-settings', 'maps'], ['15-daily-quiz', 'daily-quiz'], ['16-access-compute', 'access-compute'],
    ['17-diagnostics', 'diagnostics'], ['18-seed-ratings-upload', 'seed-ratings'], ['19-seed-ratings-one-player', 'seed-ratings', 'tab:manual'],
    ['20-seed-ratings-team-ratings', 'seed-ratings', 'tab:team'], ['21-seed-ratings-review', 'seed-ratings', 'seedpreview'],
    ['22-seed-ratings-team-review', 'seed-ratings', 'teampreview'], ['23-link-profiles-review', 'link-profiles', 'idpreview'],
    ['24-import-history-blocked', 'import-history', 'migpreview']
  ],
  mobile: [
    ['01-wizard-invite', 'wizard-invite'], ['02-wizard-enable-channel', 'wizard-enable-channel', 'stepper'], ['03-dashboard-signed-out', 'dashboard-signed-out'],
    ['04-overview', 'overview'], ['05-channel-settings-unsaved', 'channel-settings', 'dirty'], ['06-daily-quiz', 'daily-quiz'],
    ['07-seed-ratings-review', 'seed-ratings', 'seedpreview'], ['08-diagnostics', 'diagnostics']
  ]
};
(async () => {
  const browser = await chromium.launch();
  for (const [device, list] of Object.entries(SHOTS)) {
    const size = device === 'desktop' ? { width: 1440, height: 900 } : { width: 390, height: 844 };
    fs.mkdirSync(`${OUTDIR}/${device}`, { recursive: true });
    for (const [file, screen, action] of list) {
      const page = await browser.newPage({ viewport: size, deviceScaleFactor: device === 'mobile' ? 2 : 1 });
      page.on('pageerror', e => console.log('PAGEERROR', file, e.message));
      await page.route('**/*', r => new URL(r.request().url()).hostname === 'localhost'
        ? r.fulfill({ status: 200, contentType: 'text/html', body: html }) : r.abort());
      await page.goto(`http://localhost/#${screen}`);
      await page.waitForTimeout(1500);
      await page.addStyleTag({ content: '#proto-panel{display:none!important}' });
      const upload = async (id, name) => page.setInputFiles('#' + id, { name, mimeType: 'text/csv', buffer: Buffer.from('user_id,rating\n1,1500\n') });
      if (action === 'dirty') { await page.fill('[data-var="rating_initial"]', '1500').catch(() => {}); await page.evaluate(() => switchTab('Auto-remove')); await page.click('[data-var="remove_offline"] + .track').catch(() => {}); }
      if (action === 'tooltip') { await page.evaluate(() => switchTab('Rating')); await page.hover('.cfg-var[data-variable="rating_system"] .info-tip button'); }
      if (action === 'search') { await page.fill('#settings-search', 'remove'); }
      if (action === 'teams') { await page.evaluate(() => switchTab('Teams')); }
      if (action === 'maps') { await page.evaluate(() => switchTab('Maps')); }
      if (action && action.startsWith('tab:')) { await page.click(`.ap-tabs button[data-tab="${action.slice(4)}"]`); }
      if (action === 'seedpreview') { await upload('seed-upload', 'players.csv'); await page.evaluate(() => previewFileRatingSeed()); }
      if (action === 'teampreview') { await page.evaluate(() => previewTeamRatings()); }
      if (action === 'idpreview') { await upload('identity-upload', 'profiles.csv'); await page.evaluate(() => previewIdentityFile()); }
      if (action === 'migpreview') { await upload('migration-upload', 'pubobot-export.zip'); await page.evaluate(() => previewHistoricalMigration()); }
      if (action === 'stepper') { await page.evaluate(() => document.querySelector('.addbot-stepper').scrollIntoView()); }
      await page.waitForTimeout(900);
      const full = action === 'full' || /preview$/.test(action || '');
      if (full) {
        const h = await page.evaluate(() => document.getElementById('main_area').scrollHeight + 70);
        await page.setViewportSize({ width: size.width, height: Math.min(h, 3600) });
        await page.evaluate(() => { document.getElementById('main_area').scrollTop = 0; });
        await page.waitForTimeout(400);
      }
      await page.screenshot({ path: `${OUTDIR}/${device}/${file}.png` });
      await page.close();
    }
  }
  await browser.close();
})();
