# NammaAoE2Bot dashboard: design handoff

This package is the design for the web dashboard's admin area: the
"Add to Discord" setup wizard, the server overview, channel and queue
settings, and the six admin tool pages (daily quiz, access & compute,
diagnostics, seed ratings, link AoE2 profiles, import match history).

It is written for the agent or developer who builds on it. Everything here
was produced from a working implementation, so the screens are real renders,
not mock-ups drawn separately.

## Start here

1. **Open `designs/prototype.html` in a browser.** It is the real dashboard
   page with a fake API built in, so every admin screen can be clicked through
   offline. Use the **Prototype** menu in the bottom-left corner to jump between
   screens. Setting names, descriptions, types, defaults and options are
   extracted from `nammaoe2bot/pickup/channel.py` and `queue.py`, so they match
   the bot.
2. **Skim `screens/`.** 24 desktop renders (1440×900) and 8 phone renders
   (390×844), numbered in the order an admin meets them.
3. **Read the guides in order** (below). If you are the backend agent, go
   straight to `guides/05-backend-notes.md`.

## Where the code is

The design is already implemented on branch **`claude/sharp-hopper-i8o8vt`**
(based on `productionize`). This branch adds only this package on top of it.

| Area | File |
| --- | --- |
| Whole front end (HTML, CSS, JS in one file) | `nammaoe2bot/web/page.html` |
| Invite link, `/add-bot` route, `invite_url` on `/api/me` | `nammaoe2bot/web/server.py` |
| Setting descriptions shown in the UI | `nammaoe2bot/pickup/channel.py`, `nammaoe2bot/pickup/queue.py` |
| Tests for the new server pieces | `tests/test_web_repoint.py` |

`designs/reference/page.html` is a copy of the implemented page at packaging
time; `designs/reference/backend-changes.patch` is the server, settings and test
diff against `productionize`.

## Contents

```
README.md                      this file
screens/desktop/*.png          24 screens, 1440×900 (long pages captured in full)
screens/mobile/*.png           8 screens, 390×844 @2x
designs/prototype.html         clickable prototype with a fake API
designs/tokens.css             colour, radius, type and motion tokens
designs/reference/page.html    the implemented page at packaging time
designs/reference/backend-changes.patch
guides/01-design-principles.md what the design is trying to do, and what it avoids
guides/02-design-system.md     tokens, type, components, states, motion
guides/03-screens-and-flows.md every screen: purpose, states, copy, interactions
guides/04-implementation-guide.md  how the page is put together and how to extend it
guides/05-backend-notes.md     open backend work: permissions, prefix, description review, version
guides/06-qa-checklist.md      what to click through before shipping
tools/                         scripts that rebuild the prototype and screens
```

## Decisions already made by the product owner

- The bot is meant to be added to other servers (and is being adapted for
  other platforms), so "Add to Discord" stays public.
- The wizard does **not** try to detect the Discord-side steps (enabling a
  channel, creating a queue) and has no "I did it" checkbox. Each of those
  steps instead tells the admin, in plain words, that the page can't see it
  happen and which bot reply to wait for. Only the last step checks the server.
- The wizard is allowed to be flashy. The admin tool pages must not look
  machine-generated: plain, ruled, labelled, one accent colour.
- The owner does the testing.

## Rebuilding the prototype and screens

From the repository root, with Node and Playwright available:

```bash
python3 tools/export_vars.py nammaoe2bot/pickup/channel.py nammaoe2bot/pickup/queue.py vars.json
python3 tools/build_proto.py nammaoe2bot/web/page.html tools/proto-mock.js vars.json prototype.html
node tools/capture.js prototype.html screens
```

`export_vars.py` reads the setting definitions straight from the source (no
database or Discord needed). Re-run it whenever a setting's text changes.
