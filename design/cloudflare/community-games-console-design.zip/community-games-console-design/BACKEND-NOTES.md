# Backend notes — `cloudflare/src/`

Things the design depends on that the current Worker may not provide.
Each says what to check first; some may already exist.

## 1. Invite permissions — done in `codex/cloudflare-responsive-ui`
The current build adds separate invite links with Manage Roles and Manage
Nicknames. The original note follows for reference.
`REQUIRED_CHANNEL_PERMISSIONS` in `cloudflare/src/discord/client.ts` is
View Channel + Send Messages + Embed Links + Read Message History (85008),
and `worker.ts` builds `inviteUrl` from it. Features in the console need
more than that:
- Rank roles (`ranks[].roleId`) need **Manage Roles** (268435456), and the
  bot's role must sit above the rank roles.
- `decorateNickname` needs **Manage Nicknames** (134217728).

Keep the base invite minimal (the setup guide promises that), and add a
second URL, e.g. `bootstrap.inviteUrlWithRoles`, with those two added. The
Players page shows it as "Grant in Discord" only when rank roles or
nickname decoration are switched on. Also check, and report in the
setup response, whether the bot currently has these permissions and
whether its top role is above every rank role, so the warning can
disappear once fixed.

## 2. "Is the bot in this server?" without an error (fix)
`GET /api/communities/:guild/setup` returns 409 `discord_unavailable` when
the bot isn't in the server. The design treats that as a waiting state
and polls it. Either keep the 409 with a stable `code` the UI can rely on,
or (better) add a cheap `GET /api/communities/:guild/status` returning
`{ botPresent, checkedAt, channels: [{ id, name, missing: [...] }] }` so
polling doesn't run the full setup query every 5 seconds.

## 3. Setup guide progress (check)
The guide derives steps 3 and 4 from the setup response (games, queues).
Confirm both are present in one response for a fresh server.

## 4. Rating engine lock (check)
The editor locks "Rating system" when the game already has player
records and says how many ("214 player records"). Confirm the setup
response exposes a record count per game, or add one.

## 5. Delivery failures (check)
Matches shows "1 message couldn't be posted" with Try again. Confirm the
delivery/audit data says which channel failed and why, and whether a
retry endpoint exists. If not, show Fix permissions only.

## 6. Version label (update)
The footer shows `bootstrap.version`. `cloudflare/package.json` says
0.16.0; make sure the deployed bootstrap reports the same value, and that
`environment` is set per deployment (the badge reads STAGING / hidden in
production).

## 7. No-servers count (optional)
`No-Servers.dc.html` says "Discord told us you're in 6 servers". That
needs the unfiltered guild count from `/users/@me/guilds`. If it isn't
cheap to return, the frontend drops the number.

## 8. Unit conversions (no change)
The UI shows minutes, hours and a time of day where the API stores
seconds and minutes after midnight UTC (`reuseSeconds`, `matchSeconds`,
`waitingSeconds`, `rally.cooldownSeconds`, `economy.taxMinuteUtc`). The
frontend converts; the API stays as it is.

## 9. Other platforms (keep in mind)
The bot is being adapted beyond Discord. The design keeps
"Add to Discord" public and in one place (setup step 2 and Setup), so a
second platform can be added as another option there later.
