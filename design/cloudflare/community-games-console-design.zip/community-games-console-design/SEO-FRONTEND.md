# SEO — front-end work

Goal: show up when people search for a Discord bot for their game
("aoe2 discord bot", "starcraft 2 inhouse bot", "beyond all reason discord
bot"…), and say plainly that it is **free** and **open source**. Full
reasoning and the search vocabulary: `seo-plan.html` in this package (also at
https://claude.ai/artifact/AnRydmmDk3oirU5EtwD9b7, private until shared).

Designs: `Main.dc.html` (home), `Site-Game.dc.html` (game page template),
`Site-Open-Source.dc.html` (open source + about), `M-Welcome.dc.html` and
`M-Site-Game.dc.html` (phone), `Theme.dc.html` (tokens).

## 1. Static public pages

- Build every public page as plain HTML at build time, with no client
  JavaScript. Suggested: `cloudflare/site/templates/*.html` +
  `cloudflare/scripts/build-site.mjs`, writing into `dist/web/` before Vite's
  console build (or Vite multi-page inputs).
- Data sources, so pages never drift from the code:
  - games: `src/games/catalog.ts` → `name`, `selection` (civilizations,
    gods, factions, races, clans), `lobby`, `occupancy`, `profileProvider`,
    `lifecycle`, `manifest.acceptance`, `manifest.limitations`;
  - commands: `src/discord/commands.mjs` → the Commands guide.
- Each game also needs a hand-written block in `cloudflare/site/games/<id>.md`
  (how a night of that game usually runs, its common team sizes, game-specific
  questions). **Fail the build** if a catalog game has no block, so new games
  can't ship without a page.
- Labels must stay honest: while `acceptance` is `pending`, lobby tracking
  says "beta". Legacy games say "captains report results". Never say results
  are automatic: captains confirm every result.

## 2. Pages and URLs

| URL | Page |
| --- | --- |
| `/` | Home (`Main.dc.html`) |
| `/games/` | All games |
| `/games/age-of-empires-2/` `/games/age-of-empires-3/` `/games/age-of-empires-4/` `/games/age-of-mythology/` `/games/warcraft-3/` `/games/beyond-all-reason/` `/games/cnc-generals-zero-hour/` `/games/cnc-generals/` `/games/starcraft-2/` `/games/northgard/` `/games/tempest-rising/` | One per game (`Site-Game.dc.html`) |
| `/features/` + `queues-and-check-in/`, `team-balancing/`, `ratings-and-leaderboards/`, `map-voting/`, `predictions/`, `lobby-tracking/`, `voice-and-rally/` | Feature pages |
| `/guides/getting-started/`, `/guides/commands/`, `/guides/permissions/`, `/guides/import-ratings/`, `/guides/switch-from-pubobot/` | Guides |
| `/open-source/`, `/about/` | `Site-Open-Source.dc.html` (two pages, same template) |
| `/faq/`, `/changelog/`, `/privacy/`, `/terms/` | Text pages in the same template |
| `/404.html` | Not-found page with links to games and home |
| `/app/…` | Organizer console (the current SPA) |

Trailing slashes on every page URL. Every page links to every game in the
footer (`Main.dc.html` footer).

## 3. Per-page head

Every public page has:
- a unique `<title>`, about 60 characters. Game pages:
  "[Game] Discord Bot — Free Pickup Queues, Team Balancing & Ratings";
- a unique meta description, about 155 characters, stating free and open source;
- `<link rel="canonical">` with the production origin;
- Open Graph and Twitter tags (`og:title`, `og:description`, `og:image`
  1200×630 per game, `og:type`, `twitter:card=summary_large_image`);
- `<html lang="en">`, favicon set (SVG, 32 px PNG, 180 px apple-touch);
- JSON-LD in `<script type="application/ld+json">`. This is a data block the
  browser doesn't run, so the current `script-src 'self'` CSP allows it:
  - home and game pages: `SoftwareApplication` with
    `"applicationCategory": "GameApplication"`, `"operatingSystem": "Discord"`,
    `offers.price "0"`, `isAccessibleForFree: true`,
    the GPL-3.0 `license` URL and `codeRepository`;
  - every page: `BreadcrumbList`;
  - about page: `Organization` with `sameAs` → GitHub and the support Discord.

## 4. Content rules

- One `h1` per page, logical heading order, descriptive link text.
- The first sentence of each game page answers the search:
  "[Name] is a free, open-source Discord bot that runs [Game] pickup games…"
- Game pages: 700–1,200 words of real, game-specific content. If a game can't
  honestly reach that, merge it with a related game rather than padding.
- Use players' words: AoE2, 4v4, team games, pickup, PUG, inhouse, Elo.
- Screenshots of the real Discord cards as WebP with width, height and alt
  text; lazy-load below the fold.
- A "Not affiliated with…" line naming the publisher on each game page.
- "Add to Discord" links carry `?ref=<page-slug>` (strip it before building the
  Discord invite URL, but count it) so installs can be traced to pages.

## 5. Console changes that SEO needs

- Move the SPA under `/app`: update `/auth/login?returnTo=…`, internal links,
  the `/stats` and `/link` routes, and the e2e base URLs.
- The console's `index.html` gets `<meta name="robots" content="noindex">`.
- Public leaderboards move from `/stats?community=…&game=…` to
  `/c/{community}/{game}/`, server-rendered by the worker (see
  `SEO-BACKEND.md`). The SPA keeps its interactive player detail there, loaded
  on top of the server HTML.

## 6. Tests to add

- Every built public page: exactly one `h1`, a unique title and description,
  a canonical URL, valid JSON-LD (parse it), and an entry in `sitemap.xml`.
- Every catalog game has a page and a hand-written block.
- No public page loads a script (other than analytics if approved).
- Lighthouse SEO and accessibility ≥ 95 on home and one game page, desktop and
  mobile.
