# Implementation guide — Cloudflare organizer console

Target: `cloudflare/web/` (Vite, plain TypeScript, no framework). Keep the
existing API calls; this is a presentation and flow change.

## 1. Hard constraints (the production CSP)

`cloudflare/web/public/_headers` ships:
`default-src 'self'; script-src 'self'; style-src 'self'; img-src 'self' https://cdn.discordapp.com; connect-src 'self'; frame-ancestors 'none'; base-uri 'none'; form-action 'self'`

So in the real app:
- **No inline `style="…"` attributes and no inline handlers.** The design
  frames use inline styles only because that is the canvas format. Move
  every style into `style.css` classes. Dynamic widths (progress bars)
  use a class set (`.fill-0` … `.fill-100` in steps of 5) or the
  `<progress>`/`<meter>` element styled in CSS.
- **No CDN.** The canvas loads IBM Plex from Google Fonts only because the
  canvas can't host files; the app self-hosts the woff2 files under
  `web/public/fonts/` with `@font-face` in `style.css`.
- Icons are inline SVG built in TypeScript (stroke 2, round caps,
  `aria-hidden="true"` when decorative).
- No emoji, no gradients, no left-border accent cards.

## 2. Tokens

Put these on `:root` in `style.css`.

| Token | Value | Use |
| --- | --- | --- |
**v2 (31 Oct 2026): light is the default; dark is an option only.** The
canvas board `Theme.dc.html` shows both palettes and the do/don't list.

| Token | Light (default) | Dark (option) | Use |
| --- | --- | --- | --- |
| `--bg` | `#f3f3f0` | `#18191b` | Page |
| `--surface` | `#ffffff` | `#202124` | Cards, header, inputs |
| `--surface-2` | `#f9f9f7` | `#1c1d20` | Card footers, inline editors |
| `--sunken` | `#f4f4f1` / `#efeeea` | `#26282b` | Stat tiles, readouts |
| `--border` | `#dedcd5` | `#303236` | Card and header borders |
| `--divider` | `#e9e8e3` | `#2a2c30` | Rows inside cards |
| `--control` | `#c8c6be` | `#43464b` | Input and secondary-button borders |
| `--ink` | `#1d1e20` | `#f0f1f2` | Headings, logo |
| `--text` | `#2e3034` | `#d9dadc` | Body |
| `--text-2` | `#3d4046` | `#c4c6ca` | Secondary body |
| `--muted` | `#5c5f66` | `#9a9da3` | Help text (4.5:1 on surface and bg) |
| `--accent` | `#28567f` | `#8fb8d8` | Primary buttons, links, selection |
| `--accent-hover` | `#1f4566` | `#a9c9e2` | |
| `--accent-ink` | `#1f4566` | `#bcd6ea` | Text on `--accent-soft` |
| `--accent-soft` | `#eef3f7` / `#e5eef4` | `#22303b` | Selected fill / chips |
| `--ok` / `--ok-soft` / `--ok-ink` | `#18794e` / `#e6f2ea` / `#0f5132` | `#7cc79c` / `#1b2e24` / `#a8dcbc` | Ready, saved, wins |
| `--warn` / `--warn-soft` / `--warn-ink` | `#b8741a` / `#f6ecd9` / `#7a4a00` | `#e0b06a` / `#33291a` / `#efcf9c` | Changed, checking in |
| `--danger` / `--danger-soft` / `--danger-ink` | `#b42318` / `#f8e6e3` / `#8f1d14` | `#f0958b` / `#3a2220` / `#f7bdb6` | Destructive, missing permission |
| Discord preview | `#1d1e20` frame, `#2b2d31` message, Discord's own green/grey buttons | same | Only inside "what players see" previews |

Dark theme: same structure, no glow, no coloured borders on idle controls,
primary button = `--accent` fill with `#18191b` text.

Radii: 6 (buttons, inputs, chips), 8 (cards), 10–12 (dialogs, bottom sheet).
Pills 999. No shadows except dialogs and the bottom sheet.
Type: **IBM Plex Sans** and **IBM Plex Mono**, self-hosted woff2 in
`web/public/fonts/` (the CSP allows fonts from `'self'`), with the system
stack as fallback. Body 15 px console / 16 px public site and phone (16 px
inputs stop iOS zoom). H1 30 px console, 34 px setup guide, 44–50 px public
pages. Weights 400/600/700 only. Labels and headings in sentence case; no
uppercase eyebrows. Numbers use `font-variant-numeric: tabular-nums`.
Touch targets ≥ 44 px everywhere; phone primary actions are 48–52 px.

## 3. Components (build once, reuse)

- **Header (console):** logo mark · server switcher button · tabs Queues /
  Matches (count badge of live matches) / Players / Setup (dot when Setup
  has issues) · environment badge (from `bootstrap.environment`) · public
  page link · account button. Active tab: 3 px accent underline and
  `aria-current="page"`.
- **Card** (`.card`): surface, 1 px border, radius 14.
- **Setting row:** label + help on the left (`flex: 1 1 260px`), control on
  the right (`flex: 1 1 320px`); wraps to stacked on narrow screens.
  Rows are separated by `--divider`.
- **Info tip:** an icon button (`aria-label="More about <label>"`,
  `aria-expanded`) next to the label. Desktop: a dark popover under the
  label with a sentence plus a `<dl>` of Default / Allowed / Applies to.
  Phone: the same content in a bottom sheet (`role="dialog"`,
  `aria-modal`, "Got it" button, tap scrim to close, Esc closes, focus
  returns to the icon). Every numeric setting gets one; text for each is
  in `Queue-Editor.dc.html` and the table in §5.
- **Switch:** `<button role="switch" aria-checked>`; 48×28 desktop,
  52×32 phone. Disabled: grey track, `not-allowed`.
- **Choice card:** a `<label>` wrapping a radio; selected = 2 px accent
  border + `--accent-soft`.
- **Segmented control:** radios inside a bordered group; selected segment
  is `--ink` with white text.
- **Status pill:** dot + text. Open (ok), Paused (grey, pause glyph),
  Checking in (warn), Awaiting result (accent), Won (ok), Draw (grey),
  Cancelled (danger), Check-in incomplete (warn), Result withdrawn (grey).
  Text always says the state; colour is never the only signal.
- **Readout chip:** grey chip after a number input showing the human
  form: `90` seconds → `1 min 30 s`; `8` players → `4 vs 4`.
- **Unsaved bar:** dark bar at the top of the editor (desktop) / pinned
  above the bottom edge (phone) listing what changed, with Discard and
  Save. Changed fields get a "Changed" pill and a warn-coloured border;
  the category nav shows a warn dot and "1 change".
- **Discord preview:** the dark panel that mimics the bot's queue card.
  It is decoration: `aria-hidden` or a short `aria-label`.

## 4. Flows

### Signed out (`Main.dc.html`, `M-Welcome.dc.html`)
Show when `bootstrap.user` is null. Primary button goes to the existing
OAuth start route. If `oauthReady` is false, replace the button with a
plain sentence: "Sign-in isn't configured on this deployment yet."

### Setup guide (`Setup-*.dc.html`, `M-Setup-*.dc.html`)
Shown instead of the console when the chosen server is not fully set up.
Steps and how each is decided:

| Step | Done when |
| --- | --- |
| 1 Sign in | `bootstrap.user` present |
| 2 Invite the bot | `GET /api/communities/:guild/setup` succeeds (today a 409 `discord_unavailable` means not invited) |
| 3 Add a game | the setup response lists at least one game |
| 4 First queue | at least one queue exists |
| 5 Try it in Discord | **Never "done".** It is a note. No checkbox, no tracking. "Go to my console" leaves the guide |

Step 2 details:
- "Add to <server>" opens `${inviteUrl}&guild_id=${guildId}&disable_guild_select=true` in a new tab.
- **Check again** re-requests setup. While waiting, poll every 5 s only
  while the tab is visible (`visibilitychange`), stop after 10 minutes,
  and also re-check on window `focus`. Show "Checked at HH:MM".
- 409 is a *waiting* state, not an error: neutral panel, never red.
- On success show the green panel and the Continue button; never leave
  the page on "Loading settings…".

Step 3 uses the catalog from `bootstrap.catalog` as cards. "Something
else" reveals a name field (custom game). For `aoe2` show the lobby
options (`autoLobby`, `lobbyName`, default "NammaNomad").

Step 4 posts the same payload `queueSection()` builds today with only
`name`, `channelId`, `size`, `teamMethod` filled; everything else takes
the server defaults. Channels whose permission check fails are listed
but disabled, with the reason in the option text.

### No servers (`No-Servers.dc.html`)
`/api/communities` returned an empty list. Show the three ways forward
and a copyable `inviteUrl`.

## 5. Queue editor — categories and field mapping

Form field names are today's names in `main.ts`; keep them so the submit
handler keeps working.

| Category | Field (UI label) | Form name | Control | Help / tip |
| --- | --- | --- | --- | --- |
| Basics | Name | `name` | text, max 40, counter | Shown on the card; typed after /add |
| | Channel | `channelId` | select, unusable channels disabled with reason | |
| | Players per match | `size` | number, step 2, min 2 + "4 vs 4" chip | Starts when this many joined |
| | Open for players | `enabled` | switch | Paused queues keep settings and history |
| | Default queue in #channel | `isDefault` | switch | One per channel |
| | Start automatically when full | `autoStart` | switch | |
| | Nicknames | `aliases` | chip input, max 10 | Joined with commas on submit |
| Check-in | Ask players to check in | `checkIn` | switch | |
| | Time to check in | `seconds` | number (s) + readout | Default 60 · 1 s–1 h · new matches only |
| | Keep check-ins for | `reuseSeconds` | number shown in **minutes** (0–15) | Convert ×60 on submit |
| Teams and rating | How teams are made | `teamMethod` | choice cards balanced/captain/random | |
| | Rating system | `ratingEngine` | select; **locked** with reason when the game has records | |
| | Advanced numbers | `rating-*` | collapsed `<details>` | initial 1000, deviation 200, min 100, win/loss scale 100, draw 0, streak boosts |
| Who can join | Only players with this role | `requiredRole` | role select by **name** ("Anyone") | |
| | Never players with this role | `blockedRole` | role select ("Nobody") | |
| | Bot moderators | `adminRoles` | checkbox chips by role name | Owners/Manage Server already can |
| Timers and card | Remove waiting players after | `waitingSeconds` | number + unit select (min/h/days), max 14 days | 0 keeps them |
| | Cancel a match with no result after | `matchSeconds` | number in **hours**, max 12 | 0 never |
| | Keep the card near the bottom | `keepQueueVisible` | switch | |
| Features | Gold, Predictions, Civilization picks, Map selection, Match stories, Daily quiz | `module-*` | switch rows | Predictions disabled unless Gold; Civs only for AoE II; Quiz shows "Coming later", disabled |
| | Weekly gold tax | `taxEnabled` | switch | |
| | Weekly gold tax time | `taxMinuteUtc` | `<input type="time">` in UTC, local time shown beside it | Convert HH:MM ↔ minutes on load/submit |
| Maps | Map pool | `mapPool` | textarea, one per line, live count | |
| | How maps are chosen | `mapMode` | segmented vote/random/direct ("Captains pick") | |
| | Maps per match / Choices / Voting time / Skip recent | `mapCount` / `mapShortlist` / `mapSeconds` / `mapRecent` | numbers with units | Ranges as in the frame |
| | If votes tie / If nobody votes | `mapTie` / `mapNoVotes` | selects | |
| | Voting counts as check-in | `mapCheckIn` | switch | |
| Voice and rally | Show who's in voice | `voicePreview` | switch | No audio processed |
| | Allow /rally | `rallyEnabled` | switch | |
| | Voice channels | `rallyChannels` | checkbox chips by **channel name** (not IDs) | |
| | Also mention | `rallyRoles` | role select by name | |
| | Cooldown | `rallyCooldown` | number in **minutes** (1–60) | ×60 on submit |
| | People per rally | `rallyMentions` | number 1–8 | |

Rules: the left nav is anchor links (`#basics` …); on phone it becomes a
horizontally scrolling chip row. Validation messages appear under the
field in `--danger-ink`, and Save scrolls to the first error. After saving
show "Saved. New matches use these settings; matches already running keep
theirs." Removing a queue asks for the queue name to be typed.

## 6. Other console screens

- **Queues:** one card per queue from the setup response. "Start with N
  now" and "Clear queue" are the existing queue controls; both confirm
  first. Paused queue cards show Resume as the primary action.
- **Matches:** live matches first, then a finished table. Recording a
  result is two steps: pick the outcome, read the plain-language preview
  of what happens (ratings, predictions, that it can be withdrawn), then
  confirm. Same for Cancel, Replace a player, Withdraw result. Delivery
  failures from the delivery/audit data surface as a warn card with
  "Fix permissions" and "Try again". The activity list is the audit log,
  newest first.
- **Players:** one game at a time. "Manage" expands an inline row (rating
  + uncertainty, restrict for a duration, hide, profile link actions).
  Leaderboard visibility is three choice cards; ranks are an editable
  table with role pickers; import is Source → Preview → Apply with counts
  of set / unchanged / need a look.
- **Setup:** bot status, games, the per-channel permission matrix built
  from the existing channel permission data, numbered fix steps, who can
  sign in, public page link, footer with `bootstrap.version` and
  environment.
- **Statistics (public):** dark header with community and game,
  leaderboard on the left, selected player on the right (stacks on
  phone). The chart is one accent line, with an `aria-label` that
  summarises the trend.

## 7. Phone (≤ 640 px)

- Header: server switcher, environment badge, account. No tabs in the header.
- Bottom tab bar: Queues · Matches (badge) · Players · Setup, 56 px tall,
  plus `env(safe-area-inset-bottom)` padding.
- Sub-pages (queue editor, setup guide) replace the tab bar with a back
  button in the header and a pinned action footer.
- Tables become lists: one row per item, tap to expand.
- Tips open as bottom sheets.
- No horizontal page scroll; chip rows scroll inside themselves.
- Tablet (641–1024 px): desktop layout; sidebars drop under the main
  column through the existing flex-wrap.

## 8. Accessibility checklist

Real buttons, links and labels; every icon-only button has an
`aria-label`; `aria-current` on the active tab and setup step;
`role="status"` on waiting / saved / unsaved messages so screen readers
hear them; visible focus ring (2 px `--accent`, 2 px offset); colour
never carries meaning alone; text contrast ≥ 4.5:1 (the tokens above
pass).
