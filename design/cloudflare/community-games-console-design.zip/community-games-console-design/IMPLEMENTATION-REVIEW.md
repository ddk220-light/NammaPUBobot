# Review of the current build — what to fix

Reviewed: branch `codex/cloudflare-responsive-ui` (commit `314aef5`), built and
run against its own Playwright fixtures at 1440 px and 390 px. Type check,
build and 882 unit tests pass; 49 of 50 browser tests passed on the first
run (see item 12).

The owner's direction for this round: **light theme by default, and a look
that doesn't read as AI-generated** — no glowing borders, no neon accents.
Everything below is to be fixed. The matching frames are on the design
canvas (https://claude.ai/artifact/GY8vuTZcFZYyFCShx43EuJ); yellow stickies
on the canvas repeat these points next to the screens they affect.

## Must fix

1. **Wrong command in the setup guide.** `web/guide.ts:144` tells players to
   use `/join`. The command is `/add` (`src/discord/commands.mjs:42`).
2. **Change review dumps raw fields.** Adding one game and one queue shows
   "101 changed values" and a dialog of rows like
   "Ranks → 0 → Role Id: Not set → None" and "Catalog Id: aoe2"
   (`web/change-review.ts`). Replace with the summary in
   `Review-Changes.dc.html`:
   - one line per real change, grouped as Adds / Creates / Changes / Removes;
   - changed values shown as `old → new` in settings wording;
   - values that only took a default are not listed;
   - the full field list stays available behind "Show every saved field",
     in settings wording, defaults marked "default";
   - the save bar says "3 changes", not "101 changed values".
3. **Theme.** Make light the default. Dark is an option only
   (`prefers-color-scheme` or an account-menu toggle). Use the tokens on
   `Theme.dc.html` and in `IMPLEMENTATION.md` §2. Remove:
   - the gold uppercase eyebrows ("ORGANIZE YOUR NEXT GAME",
     "MAKE IT YOURS", "A BETTER GAME NIGHT", "WORKSPACE");
   - Discord blurple for our own buttons and the filled-pill active nav item;
   - bright outlines on idle controls (the community select on load has a
     glowing focus ring without focus), outlined pills on every badge;
   - the yellow diamond logo tile and the "Play together. Make it yours."
     sidebar tagline;
   - nested boxes (card inside card inside card on Queues and Matches).
   Self-host IBM Plex Sans and IBM Plex Mono (woff2 under `web/public/fonts/`;
   the CSP already allows fonts from `'self'` via `default-src`).
4. **Setup guide clutter** (`web/guide.ts`, Setup view in `web/main.ts`):
   - one step list, not a 4-step progress card plus a different 4-tab guide;
   - while the guide runs it replaces the Setup page; Games and Discord access
     return to Setup afterwards;
   - step 1 hides "Add to Discord" and "I'm back — check access" once access
     is verified;
   - the game step is the card picker from `Setup-Game.dc.html` (11 games,
     each labelled "lobby tracking (beta)" or "captains report results"), with
     the AoE2 lobby-name option, not a dropdown.
5. **Bot not invited shows a red error.** `Invite the bot or restore access,
   then check again.` renders as an error banner. It is a waiting state:
   neutral panel, "Checked at HH:MM", "Check again" (see `Setup-Invite.dc.html`).
6. **Discord access table shows a raw channel ID** ("Channel
   706320010368516200") before verification. Show the channel name from the
   saved settings, with "Not checked yet" as the status.

## Should fix (differences from the design that the owner confirmed)

7. **Queue cards** (`Queues.dc.html`): progress bar, waiting players by name
   with rating, buttons "Start with N now", "Clear queue", "Pause" directly on
   the card. Today it is "0 waiting / 8 capacity", a "Start with saved rules"
   dropdown and a separate "Review queue action" button. Add the "Happening
   now" panel.
8. **Matches** (`Matches.dc.html`): the "Who won?" picker with its plain
   preview sits on the live match card. Today it is inside a collapsed
   "Administrator actions". Queue controls, delivery problems and the activity
   log are visible panels, not collapsed rows.
9. **Signed-out page → public home.** The `/` route becomes the public landing
   page (`Main.dc.html`), built as static HTML (see `SEO-FRONTEND.md`). The
   console moves to `/app`.
10. **Phone navigation.** Keep the bottom tab bar (Queues, Matches, Players,
    Setup) from the phone frames, not a menu drawer. Move Refresh into the
    account menu and Sign out into the account sheet so the header holds only
    the server switcher and account button.
11. **Sentence case and plain words** everywhere: "Players per match" not
    "Players", "How teams are made" not "Team formation", "Captains pick" not
    "Captain pick", "Nicknames" not "Queue aliases".

## Housekeeping

12. `e2e/console-handoff.spec.ts:128` ("player cards preserve scoped actions…")
    failed once in a full parallel run and passed in 61 later runs. Look for a
    race in that spec before it becomes a CI flake.
13. Update `e2e/` snapshots and selectors as the copy above changes; keep the
    390 / 430 / 640 / 641 / 768 / 844×390 / 900 / 901 / 1440 viewport sweep.
